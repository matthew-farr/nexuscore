// Seed/demo data for Learning Hub - used when DB is empty

export const SEED_COURSES = [
  { title: "DBS Eligibility Fundamentals", category: "DBS & Compliance", difficulty: "Beginner", duration_minutes: 45, modules_count: 5, description: "Learn the fundamentals of DBS eligibility, check types and workforce categories.", status: "published", tags: ["DBS", "Compliance", "Eligibility"] },
  { title: "Enhanced DBS Checks Explained", category: "DBS & Compliance", difficulty: "Intermediate", duration_minutes: 60, modules_count: 6, description: "Deep dive into Enhanced DBS checks, barred lists and regulated activity.", status: "published", tags: ["DBS", "Enhanced", "Barred Lists"] },
  { title: "Adult Barred List Criteria", category: "DBS & Compliance", difficulty: "Intermediate", duration_minutes: 30, modules_count: 4, description: "Understanding Adult Barred List criteria and when it applies.", status: "published", tags: ["Adult Barred List", "Compliance"] },
  { title: "Child Workforce Frequency Test", category: "DBS & Compliance", difficulty: "Advanced", duration_minutes: 40, modules_count: 4, description: "Applying the frequency test to child workforce regulated activity scenarios.", status: "published", tags: ["Frequency Test", "Children"] },
  { title: "Right to Work Checks", category: "Operations", difficulty: "Beginner", duration_minutes: 35, modules_count: 4, description: "How to conduct compliant Right to Work checks for all employee types.", status: "published", tags: ["Right to Work", "Compliance"] },
  { title: "Overseas Checks Process", category: "Operations", difficulty: "Intermediate", duration_minutes: 50, modules_count: 5, description: "Processing overseas criminal record checks and country-specific requirements.", status: "published", tags: ["Overseas", "International"] },
  { title: "HubSpot Basics for Sales", category: "HubSpot", difficulty: "Beginner", duration_minutes: 55, modules_count: 7, description: "Getting started with HubSpot CRM: contacts, deals, pipelines and activities.", status: "published", tags: ["HubSpot", "CRM", "Sales"] },
  { title: "Customer Service Standards", category: "Customer Service", difficulty: "Beginner", duration_minutes: 40, modules_count: 5, description: "Checks Direct customer service standards, communication and handling difficult situations.", status: "published", tags: ["Customer Service", "Communication"] },
  { title: "Data Protection & GDPR Refresher", category: "Health & Safety", difficulty: "Beginner", duration_minutes: 30, modules_count: 3, description: "Annual GDPR refresher covering data subject rights, breach reporting and best practice.", status: "published", tags: ["GDPR", "Data Protection"] },
  { title: "New Starter Induction", category: "Onboarding", difficulty: "Beginner", duration_minutes: 90, modules_count: 10, description: "Complete onboarding programme for new Checks Direct team members.", status: "published", tags: ["Induction", "Onboarding", "New Starter"] },
];

export const SEED_PATHS = [
  { title: "New Starter Journey", description: "Everything a new team member needs to get up to speed at Checks Direct.", category: "Onboarding", estimated_duration_minutes: 240, courses_count: 4, colour: "#8b5cf6", icon: "Rocket" },
  { title: "Operations Academy", description: "Master DBS checks, overseas processes and operational compliance.", category: "Operations", estimated_duration_minutes: 200, courses_count: 4, colour: "#0ea5e9", icon: "Settings2" },
  { title: "Sales Excellence", description: "HubSpot mastery, customer service and commercial skills.", category: "Sales", estimated_duration_minutes: 150, courses_count: 3, colour: "#ec2ca3", icon: "TrendingUp" },
  { title: "Compliance Essentials", description: "Core compliance knowledge every Checks Direct employee must complete.", category: "DBS & Compliance", estimated_duration_minutes: 165, courses_count: 4, colour: "#10b981", icon: "Shield" },
  { title: "Manager Development", description: "Leadership, team management and performance skills for managers.", category: "Management", estimated_duration_minutes: 180, courses_count: 3, colour: "#f59e0b", icon: "Users2" },
];

export const CATEGORY_COLOURS = {
  "DBS & Compliance": { bg: "rgba(16,185,129,0.15)", border: "rgba(16,185,129,0.30)", text: "#10b981", icon: "Shield" },
  "Operations":       { bg: "rgba(14,165,233,0.15)", border: "rgba(14,165,233,0.30)", text: "#0ea5e9", icon: "Settings2" },
  "Sales":            { bg: "rgba(236,44,163,0.15)",  border: "rgba(236,44,163,0.30)",  text: "#ec2ca3", icon: "TrendingUp" },
  "Customer Service": { bg: "rgba(139,92,246,0.15)",  border: "rgba(139,92,246,0.30)",  text: "#8b5cf6", icon: "HeadphonesIcon" },
  "Leadership":       { bg: "rgba(245,158,11,0.15)",  border: "rgba(245,158,11,0.30)",  text: "#f59e0b", icon: "Star" },
  "Systems Training": { bg: "rgba(99,102,241,0.15)",  border: "rgba(99,102,241,0.30)",  text: "#6366f1", icon: "Monitor" },
  "HubSpot":          { bg: "rgba(249,115,22,0.15)",  border: "rgba(249,115,22,0.30)",  text: "#f97316", icon: "Zap" },
  "Health & Safety":  { bg: "rgba(239,68,68,0.15)",   border: "rgba(239,68,68,0.30)",   text: "#ef4444", icon: "AlertTriangle" },
  "Management":       { bg: "rgba(245,158,11,0.15)",  border: "rgba(245,158,11,0.30)",  text: "#f59e0b", icon: "Users2" },
  "Onboarding":       { bg: "rgba(34,211,238,0.15)",  border: "rgba(34,211,238,0.30)",  text: "#22d3ee", icon: "Rocket" },
};

export const DIFFICULTY_STYLES = {
  Beginner:     { cls: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30" },
  Intermediate: { cls: "text-amber-400 bg-amber-500/10 border-amber-500/30" },
  Advanced:     { cls: "text-red-400 bg-red-500/10 border-red-500/30" },
};

export const STATUS_STYLES = {
  not_started: { label: "Not Started", cls: "text-slate-400 bg-slate-500/10 border-slate-500/30" },
  in_progress:  { label: "In Progress", cls: "text-blue-400 bg-blue-500/10 border-blue-500/30" },
  completed:    { label: "Completed",   cls: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30" },
  overdue:      { label: "Overdue",     cls: "text-red-400 bg-red-500/10 border-red-500/30" },
};

export const PRIORITY_STYLES = {
  low:       { label: "Low",       cls: "text-slate-400 bg-slate-500/10 border-slate-500/30" },
  medium:    { label: "Medium",    cls: "text-blue-400 bg-blue-500/10 border-blue-500/30" },
  high:      { label: "High",      cls: "text-amber-400 bg-amber-500/10 border-amber-500/30" },
  mandatory: { label: "Mandatory", cls: "text-red-400 bg-red-500/10 border-red-500/30" },
};

export function formatDuration(minutes) {
  if (!minutes) return "—";
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

export function isOverdue(dueDate) {
  if (!dueDate) return false;
  return new Date(dueDate) < new Date();
}

export function daysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
}