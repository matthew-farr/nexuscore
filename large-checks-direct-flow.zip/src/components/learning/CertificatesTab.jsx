import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Award, Download, ChevronRight, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { daysUntil } from './learningData';

const CERT_STATUS = {
  active:         { label: 'Active',         icon: CheckCircle2, cls: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
  expiring_soon:  { label: 'Expiring Soon',  icon: AlertTriangle, cls: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
  expired:        { label: 'Expired',        icon: XCircle, cls: 'text-red-400 bg-red-500/10 border-red-500/30' },
};

// Demo certificates when none in DB
const DEMO_CERTS = [
  { id: 'd1', certificate_name: 'DBS Eligibility Fundamentals', course_id: null, issued_date: '2025-11-01', expiry_date: '2026-11-01', status: 'active' },
  { id: 'd2', certificate_name: 'Data Protection & GDPR', course_id: null, issued_date: '2025-06-15', expiry_date: '2026-06-15', status: 'expiring_soon' },
  { id: 'd3', certificate_name: 'New Starter Induction', course_id: null, issued_date: '2025-01-10', expiry_date: null, status: 'active' },
];

export default function CertificatesTab({ certificates, courses, userId }) {
  const [filter, setFilter] = useState('all');

  const certs = certificates.length > 0 ? certificates : (userId ? [] : DEMO_CERTS);

  const enriched = useMemo(() => {
    return certs.map(cert => {
      const course = courses.find(c => c.id === cert.course_id);
      const days = daysUntil(cert.expiry_date);
      let status = cert.status;
      if (!status) {
        if (!cert.expiry_date) status = 'active';
        else if (days !== null && days < 0) status = 'expired';
        else if (days !== null && days <= 30) status = 'expiring_soon';
        else status = 'active';
      }
      return { ...cert, course, status, daysUntilExpiry: days };
    }).filter(c => filter === 'all' || c.status === filter);
  }, [certs, courses, filter]);

  return (
    <div>
      {/* Filter tabs */}
      <div className="flex gap-1 p-1 rounded-xl w-fit mb-6" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
        {['all', 'active', 'expiring_soon', 'expired'].map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all capitalize"
            style={filter === s
              ? { background: 'linear-gradient(135deg, #8b5cf6, #6366f1)', color: '#fff' }
              : { color: 'rgba(255,255,255,0.50)' }}>
            {s === 'all' ? 'All' : s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {enriched.length === 0 ? (
        <div className="text-center py-16">
          <Award className="w-12 h-12 mx-auto mb-3" style={{ color: 'rgba(139,92,246,0.30)' }} />
          <p className="text-white/40 text-sm">No certificates found.</p>
          <p className="text-white/25 text-xs mt-1">Complete courses to earn certificates.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {enriched.map((cert, i) => {
            const statusStyle = CERT_STATUS[cert.status] || CERT_STATUS.active;
            const StatusIcon = statusStyle.icon;
            return (
              <motion.div key={cert.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl p-5 flex flex-col gap-3"
                style={{ background: 'linear-gradient(145deg, rgba(255,255,255,0.06), rgba(255,255,255,0.03))', border: '1px solid rgba(255,255,255,0.09)' }}>
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.30)' }}>
                    <Award className="w-5 h-5 text-amber-400" />
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border flex items-center gap-1 ${statusStyle.cls}`}>
                    <StatusIcon className="w-2.5 h-2.5" /> {statusStyle.label}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white leading-snug mb-0.5">{cert.certificate_name}</h3>
                  {cert.course && <p className="text-xs" style={{ color: 'rgba(255,255,255,0.40)' }}>{cert.course.title}</p>}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span style={{ color: 'rgba(255,255,255,0.40)' }}>Issued</span>
                    <span className="text-white font-medium">{cert.issued_date ? new Date(cert.issued_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</span>
                  </div>
                  {cert.expiry_date && (
                    <div className="flex items-center justify-between text-xs">
                      <span style={{ color: 'rgba(255,255,255,0.40)' }}>Expires</span>
                      <span className={cert.daysUntilExpiry !== null && cert.daysUntilExpiry <= 30 ? 'text-amber-400 font-medium' : 'text-white font-medium'}>
                        {new Date(cert.expiry_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                        {cert.daysUntilExpiry !== null && cert.daysUntilExpiry > 0 && cert.daysUntilExpiry <= 30 && ` (${cert.daysUntilExpiry}d)`}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-auto pt-2" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                  {cert.certificate_url ? (
                    <a href={cert.certificate_url} target="_blank" rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 h-8 rounded-xl text-xs font-semibold text-white transition-all hover:opacity-90"
                      style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)' }}>
                      <Download className="w-3 h-3" /> Download
                    </a>
                  ) : (
                    <button className="flex-1 flex items-center justify-center gap-1.5 h-8 rounded-xl text-xs font-semibold transition-all"
                      style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.50)' }}>
                      <Download className="w-3 h-3" /> Download
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}