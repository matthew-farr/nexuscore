import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Send, BookOpen, RotateCcw } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const PROMPTS = [
  "What training should a new starter complete?",
  "Recommend DBS training for Operations staff",
  "Explain Adult Barred List criteria",
  "What courses are recommended for Sales?",
  "Suggest a learning path for a new Account Manager",
  "What is the Frequency Test for child workforce?",
];

function Message({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
          style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
          <Sparkles className="w-3.5 h-3.5 text-white" />
        </div>
      )}
      <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed`}
        style={isUser
          ? { background: 'linear-gradient(135deg, #8b5cf6, #6366f1)', color: '#fff' }
          : { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.09)', color: 'rgba(255,255,255,0.85)' }}>
        {msg.content}
      </div>
    </div>
  );
}

export default function AILearningTab({ user }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hello! I'm your AI Learning Assistant. I can recommend training, explain DBS processes, suggest learning paths and answer questions about courses. What would you like to know?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const sendMessage = async (text) => {
    const content = text || input.trim();
    if (!content || loading) return;
    setInput('');
    const newMessages = [...messages, { role: 'user', content }];
    setMessages(newMessages);
    setLoading(true);

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an AI Learning Assistant for Checks Direct staff training platform. 
      
User: ${user?.full_name || 'Staff member'}
Their question: ${content}

Available courses include: DBS Eligibility Fundamentals, Enhanced DBS Checks, Adult Barred List Criteria, Child Workforce Frequency Test, Right to Work Checks, Overseas Checks Process, HubSpot Basics for Sales, Customer Service Standards, Data Protection & GDPR Refresher, New Starter Induction.

Available Learning Paths: New Starter Journey, Operations Academy, Sales Excellence, Compliance Essentials, Manager Development.

Provide a helpful, concise response specific to learning and training at Checks Direct. Keep it focused and practical. Use bullet points where helpful. Do not mention AI or that you're a language model.`,
    });

    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-280px)] min-h-[500px]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)', boxShadow: '0 4px 16px rgba(139,92,246,0.40)' }}>
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">AI Learning Assistant</h3>
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.40)' }}>Powered by AI · Trained on Checks Direct courses</p>
          </div>
        </div>
        <button onClick={() => setMessages([{ role: 'assistant', content: "Hello! I'm your AI Learning Assistant. How can I help with your training today?" }])}
          className="p-2 rounded-xl hover:bg-white/10 transition-colors" style={{ color: 'rgba(255,255,255,0.40)' }}>
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Prompt suggestions */}
      {messages.length <= 1 && (
        <div className="flex flex-wrap gap-2 mb-4 flex-shrink-0">
          {PROMPTS.map(p => (
            <button key={p} onClick={() => sendMessage(p)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all hover:bg-purple-500/10 text-left"
              style={{ background: 'rgba(139,92,246,0.10)', borderColor: 'rgba(139,92,246,0.25)', color: '#c4b5fd' }}>
              <BookOpen className="w-3 h-3 flex-shrink-0" />
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 mb-4">
        {messages.map((m, i) => <Message key={i} msg={m} />)}
        {loading && (
          <div className="flex gap-3 justify-start">
            <div className="w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="rounded-2xl px-4 py-3" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.09)' }}>
              <div className="flex gap-1 items-center h-4">
                {[0,1,2].map(i => (
                  <motion.div key={i} className="w-1.5 h-1.5 rounded-full bg-purple-400"
                    animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input */}
      <div className="flex-shrink-0 flex gap-2">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
          placeholder="Ask about courses, training or learning paths…"
          className="flex-1 px-4 h-10 rounded-xl text-sm text-white placeholder:text-white/30 outline-none"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}
          disabled={loading}
        />
        <button onClick={() => sendMessage()} disabled={!input.trim() || loading}
          className="w-10 h-10 rounded-xl flex items-center justify-center transition-all hover:opacity-90 disabled:opacity-40"
          style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
          <Send className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
}