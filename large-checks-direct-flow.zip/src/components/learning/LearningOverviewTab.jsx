import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Award, AlertTriangle, BookOpen, Star } from 'lucide-react';
import CourseCard from './CourseCard';
import { isOverdue, daysUntil, formatDuration, CATEGORY_COLOURS } from './learningData';

function SectionHeader({ title, count, onViewAll }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-sm font-bold text-white">{title} {count !== undefined && <span className="text-white/30 font-normal ml-1">({count})</span>}</h2>
      {onViewAll && (
        <button onClick={onViewAll} className="flex items-center gap-1 text-xs font-semibold transition-colors hover:text-purple-300" style={{ color: '#c4b5fd' }}>
          View all <ChevronRight className="w-3 h-3" />
        </button>
      )}
    </div>
  );
}

export default function LearningOverviewTab({ courses, assignments, certificates, paths, user, onView, onTabChange }) {
  const inProgress = useMemo(() => assignments.filter(a => a.status === 'in_progress'), [assignments]);
  const overdueCourses = useMemo(() =>
    assignments.filter(a => a.status !== 'completed' && isOverdue(a.due_date))
      .map(a => ({ assignment: a, course: courses.find(c => c.id === a.course_id) })).filter(r => r.course),
    [assignments, courses]);

  const assigned = useMemo(() =>
    assignments.filter(a => a.status !== 'completed')
      .slice(0, 4)
      .map(a => ({ assignment: a, course: courses.find(c => c.id === a.course_id) })).filter(r => r.course),
    [assignments, courses]);

  const expiringSoon = useMemo(() =>
    certificates.filter(c => {
      const d = daysUntil(c.expiry_date);
      return d !== null && d >= 0 && d <= 60;
    }).slice(0, 3),
    [certificates]);

  const recommended = useMemo(() => {
    const assignedIds = new Set(assignments.map(a => a.course_id));
    return courses.filter(c => !assignedIds.has(c.id) && c.status === 'published').slice(0, 3);
  }, [courses, assignments]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main column */}
      <div className="lg:col-span-2 space-y-6">
        {/* Overdue alert */}
        {overdueCourses.length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="rounded-2xl p-4 flex items-start gap-3"
            style={{ background: 'rgba(239,68,68,0.10)', border: '1px solid rgba(239,68,68,0.25)' }}>
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-red-400">{overdueCourses.length} Overdue Course{overdueCourses.length > 1 ? 's' : ''}</p>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.50)' }}>
                {overdueCourses.map(r => r.course.title).join(', ')}
              </p>
            </div>
            <button onClick={() => onTabChange('assigned')} className="ml-auto flex-shrink-0 text-xs font-semibold text-red-400 hover:text-red-300 flex items-center gap-1">
              View <ChevronRight className="w-3 h-3" />
            </button>
          </motion.div>
        )}

        {/* Assigned Training */}
        <div>
          <SectionHeader title="Assigned Training" count={assigned.length} onViewAll={() => onTabChange('assigned')} />
          {assigned.length === 0 ? (
            <div className="rounded-2xl p-8 text-center" style={{ background: 'rgba(255,255,255,0.03)', border: '1px dashed rgba(255,255,255,0.08)' }}>
              <p className="text-white/30 text-sm">No assigned training at the moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {assigned.map(({ course, assignment }, i) => (
                <CourseCard key={course.id} course={course} assignment={assignment} onView={onView} index={i} compact />
              ))}
            </div>
          )}
        </div>

        {/* Learning Paths preview */}
        {paths.length > 0 && (
          <div>
            <SectionHeader title="Learning Paths" onViewAll={() => onTabChange('paths')} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {paths.slice(0, 4).map((path, i) => {
                const colour = path.colour || '#8b5cf6';
                return (
                  <div key={path.id || i} className="rounded-xl p-4 cursor-pointer transition-all hover:bg-white/[0.06]"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                    onClick={() => onTabChange('paths')}>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ background: colour }} />
                      <p className="text-xs font-bold text-white">{path.title}</p>
                    </div>
                    <p className="text-[11px] line-clamp-1 mb-2" style={{ color: 'rgba(255,255,255,0.40)' }}>{path.description}</p>
                    <div className="flex items-center gap-3 text-[10px]" style={{ color: 'rgba(255,255,255,0.35)' }}>
                      <span>{path.courses_count} courses</span>
                      <span>{formatDuration(path.estimated_duration_minutes)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Right sidebar */}
      <div className="space-y-5">
        {/* Expiring certs */}
        {expiringSoon.length > 0 && (
          <div className="rounded-2xl p-4" style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.20)' }}>
            <div className="flex items-center gap-2 mb-3">
              <Award className="w-4 h-4 text-amber-400" />
              <p className="text-xs font-bold text-amber-400 uppercase tracking-wider">Certificates Expiring</p>
            </div>
            <div className="space-y-2">
              {expiringSoon.map((cert, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="text-white/70 truncate flex-1">{cert.certificate_name}</span>
                  <span className="text-amber-400 font-medium ml-2 flex-shrink-0">{daysUntil(cert.expiry_date)}d</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Required this month */}
        <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <p className="text-xs font-bold text-white uppercase tracking-wider">Required This Month</p>
          </div>
          {assignments.filter(a => {
            if (a.status === 'completed') return false;
            const d = daysUntil(a.due_date);
            return d !== null && d >= 0 && d <= 30 && a.priority === 'mandatory';
          }).length > 0 ? (
            <div className="space-y-2">
              {assignments.filter(a => a.status !== 'completed' && daysUntil(a.due_date) !== null && daysUntil(a.due_date) >= 0 && daysUntil(a.due_date) <= 30).slice(0, 3).map((a, i) => {
                const c = courses.find(x => x.id === a.course_id);
                return c ? (
                  <div key={i} className="flex items-center justify-between text-xs cursor-pointer" onClick={() => onView(c)}>
                    <span className="text-white/70 truncate flex-1">{c.title}</span>
                    <span className="text-red-400 font-medium ml-2 flex-shrink-0">{daysUntil(a.due_date)}d</span>
                  </div>
                ) : null;
              })}
            </div>
          ) : (
            <p className="text-xs text-white/30">No mandatory courses due this month.</p>
          )}
        </div>

        {/* Recommended */}
        {recommended.length > 0 && (
          <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-4 h-4 text-purple-400" />
              <p className="text-xs font-bold text-white uppercase tracking-wider">Recommended</p>
            </div>
            <div className="space-y-2">
              {recommended.map((c, i) => {
                const cat = CATEGORY_COLOURS[c.category];
                return (
                  <div key={i} className="flex items-center gap-2 cursor-pointer group" onClick={() => onView(c)}>
                    <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: cat?.text || '#8b5cf6' }} />
                    <p className="text-xs text-white/65 group-hover:text-white transition-colors truncate flex-1">{c.title}</p>
                    <ChevronRight className="w-3 h-3 flex-shrink-0" style={{ color: 'rgba(255,255,255,0.25)' }} />
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}