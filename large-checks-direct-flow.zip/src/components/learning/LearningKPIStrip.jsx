import { motion } from 'framer-motion';
import { BookOpen, CheckCircle2, AlertTriangle, Award, Clock } from 'lucide-react';

const KPIS = [
  { key: 'assigned',   label: 'Assigned',    icon: BookOpen,       color: { bg: 'rgba(139,92,246,0.15)', border: 'rgba(139,92,246,0.30)', text: '#a78bfa' } },
  { key: 'completed',  label: 'Completed',   icon: CheckCircle2,   color: { bg: 'rgba(16,185,129,0.15)', border: 'rgba(16,185,129,0.30)', text: '#34d399' } },
  { key: 'overdue',    label: 'Overdue',     icon: AlertTriangle,  color: { bg: 'rgba(239,68,68,0.15)',  border: 'rgba(239,68,68,0.30)',  text: '#f87171' } },
  { key: 'certs',      label: 'Certificates',icon: Award,          color: { bg: 'rgba(245,158,11,0.15)', border: 'rgba(245,158,11,0.30)', text: '#fbbf24' } },
  { key: 'cpd',        label: 'CPD Hours',   icon: Clock,          color: { bg: 'rgba(34,211,238,0.15)', border: 'rgba(34,211,238,0.30)', text: '#22d3ee' } },
];

export default function LearningKPIStrip({ stats }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
      {KPIS.map((k, i) => {
        const Icon = k.icon;
        const value = stats?.[k.key] ?? 0;
        return (
          <motion.div key={k.key}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl p-4 flex flex-col gap-2"
            style={{ background: k.color.bg, border: `1.5px solid ${k.color.border}`, backdropFilter: 'blur(20px)' }}>
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: `${k.color.text}22`, border: `1px solid ${k.color.text}40` }}>
              <Icon className="w-3.5 h-3.5" style={{ color: k.color.text }} />
            </div>
            <p className="text-2xl font-extrabold text-white">{value}</p>
            <p className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.60)' }}>{k.label}</p>
          </motion.div>
        );
      })}
    </div>
  );
}