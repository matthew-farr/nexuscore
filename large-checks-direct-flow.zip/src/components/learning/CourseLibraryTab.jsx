import { useState, useMemo } from 'react';
import { Search, LayoutGrid, List } from 'lucide-react';
import CourseCard from './CourseCard';
import { CATEGORY_COLOURS } from './learningData';

const CATEGORIES = ['All', 'DBS & Compliance', 'Operations', 'Sales', 'Customer Service', 'Leadership', 'Systems Training', 'HubSpot', 'Health & Safety', 'Management', 'Onboarding'];
const DIFFICULTIES = ['All', 'Beginner', 'Intermediate', 'Advanced'];

export default function CourseLibraryTab({ courses, assignments, onView }) {
  const [category, setCategory] = useState('All');
  const [difficulty, setDifficulty] = useState('All');
  const [search, setSearch] = useState('');
  const [view, setView] = useState('grid');

  const filtered = useMemo(() => {
    return courses.filter(c => {
      if (c.status === 'archived' || c.status === 'draft') return false;
      if (category !== 'All' && c.category !== category) return false;
      if (difficulty !== 'All' && c.difficulty !== difficulty) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!c.title.toLowerCase().includes(q) && !c.description?.toLowerCase().includes(q) && !c.category.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [courses, category, difficulty, search]);

  return (
    <div>
      {/* Category pill filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-hide flex-nowrap">
        {CATEGORIES.map(cat => {
          const c = CATEGORY_COLOURS[cat];
          return (
            <button key={cat} onClick={() => setCategory(cat)}
              className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all whitespace-nowrap"
              style={category === cat
                ? { background: c?.bg || 'rgba(139,92,246,0.20)', borderColor: c?.border || 'rgba(139,92,246,0.40)', color: c?.text || '#c4b5fd' }
                : { background: 'rgba(255,255,255,0.04)', borderColor: 'rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.50)' }}>
              {cat}
            </button>
          );
        })}
      </div>

      {/* Search + difficulty + view toggle */}
      <div className="flex flex-wrap gap-3 mb-6 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: 'rgba(255,255,255,0.30)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search the course library…"
            className="w-full pl-9 pr-3 h-9 rounded-xl text-xs text-white placeholder:text-white/30 outline-none"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }} />
        </div>
        <select value={difficulty} onChange={e => setDifficulty(e.target.value)}
          className="h-9 px-3 rounded-xl text-xs outline-none"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.70)' }}>
          {DIFFICULTIES.map(d => <option key={d} value={d} style={{ background: '#0f172a' }}>{d === 'All' ? 'All Levels' : d}</option>)}
        </select>
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <button onClick={() => setView('grid')} className="p-1.5 rounded-lg transition-colors"
            style={{ background: view === 'grid' ? 'rgba(139,92,246,0.30)' : 'transparent', color: view === 'grid' ? '#c4b5fd' : 'rgba(255,255,255,0.40)' }}>
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button onClick={() => setView('list')} className="p-1.5 rounded-lg transition-colors"
            style={{ background: view === 'list' ? 'rgba(139,92,246,0.30)' : 'transparent', color: view === 'list' ? '#c4b5fd' : 'rgba(255,255,255,0.40)' }}>
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      <p className="text-xs mb-4" style={{ color: 'rgba(255,255,255,0.35)' }}>{filtered.length} course{filtered.length !== 1 ? 's' : ''} found</p>

      {filtered.length === 0 ? (
        <div className="text-center py-16"><p className="text-white/40 text-sm">No courses match your filters.</p></div>
      ) : (
        <div className={view === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" : "space-y-2"}>
          {filtered.map((course, i) => {
            const assignment = assignments.find(a => a.course_id === course.id);
            return <CourseCard key={course.id} course={course} assignment={assignment} onView={onView} index={i} compact={view === 'list'} />;
          })}
        </div>
      )}
    </div>
  );
}