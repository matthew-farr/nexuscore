import { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import CourseCard from './CourseCard';
import { isOverdue } from './learningData';

const STATUS_TABS = [
  { key: 'all',         label: 'All' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'not_started', label: 'Not Started' },
  { key: 'completed',   label: 'Completed' },
  { key: 'overdue',     label: 'Overdue' },
];

export default function MyLearningTab({ courses, assignments, onView }) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const enriched = useMemo(() => {
    return courses.map(c => {
      const asgn = assignments.find(a => a.course_id === c.id);
      const status = asgn ? (isOverdue(asgn.due_date) && asgn.status !== 'completed' ? 'overdue' : asgn.status) : 'not_started';
      return { course: c, assignment: asgn ? { ...asgn, status } : null };
    }).filter(({ course, assignment }) => {
      if (filter !== 'all') {
        const s = assignment?.status || 'not_started';
        if (s !== filter) return false;
      }
      if (search) {
        const q = search.toLowerCase();
        if (!course.title.toLowerCase().includes(q) && !course.category.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [courses, assignments, filter, search]);

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex gap-1 p-1 rounded-xl flex-wrap" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
          {STATUS_TABS.map(t => (
            <button key={t.key} onClick={() => setFilter(t.key)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
              style={filter === t.key
                ? { background: 'linear-gradient(135deg, #8b5cf6, #6366f1)', color: '#fff' }
                : { color: 'rgba(255,255,255,0.50)' }}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="relative flex-1 max-w-xs ml-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: 'rgba(255,255,255,0.30)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…"
            className="w-full pl-9 pr-3 h-9 rounded-xl text-xs text-white placeholder:text-white/30 outline-none"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }} />
        </div>
      </div>

      {enriched.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-white/40 text-sm">No courses found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {enriched.map(({ course, assignment }, i) => (
            <CourseCard key={course.id} course={course} assignment={assignment} onView={onView} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}