import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle2, ChevronRight, ChevronLeft, Layers, Clock, Award, BookOpen, PlayCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { formatDuration, CATEGORY_COLOURS } from './learningData';

const SAMPLE_MODULES = (course) => Array.from({ length: course?.modules_count || 3 }, (_, i) => ({
  id: `mock-${i}`,
  title: `Module ${i + 1}: ${['Introduction & Overview', 'Core Concepts', 'Practical Application', 'Case Studies', 'Assessment & Review'][i % 5]}`,
  type: i === (course?.modules_count || 3) - 1 ? 'quiz' : 'article',
  duration_minutes: Math.floor(Math.random() * 15) + 5,
  is_required: true,
  content: `## ${course?.title || 'Course'} — Module ${i + 1}\n\nThis module covers key concepts and practical knowledge related to ${course?.category || 'this topic'}.\n\n### Key Learning Points\n\n- Understand the fundamental principles\n- Apply best practices in real scenarios\n- Recognise common issues and how to resolve them\n- Know when to escalate\n\nComplete this module to progress to the next section.`,
}));

export default function CoursePlayerDrawer({ course, assignment, user, onClose, onProgressUpdate }) {
  const [modules, setModules] = useState([]);
  const [activeModuleIdx, setActiveModuleIdx] = useState(0);
  const [completedModules, setCompletedModules] = useState(new Set());
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  const cat = CATEGORY_COLOURS[course?.category] || CATEGORY_COLOURS['Operations'];

  useEffect(() => {
    if (!course) return;
    // Load real modules, fall back to sample
    base44.entities.CourseModule.filter({ course_id: course.id })
      .then(mods => {
        const sorted = [...mods].sort((a, b) => (a.module_order || 0) - (b.module_order || 0));
        setModules(sorted.length > 0 ? sorted : SAMPLE_MODULES(course));
      })
      .catch(() => setModules(SAMPLE_MODULES(course)));
  }, [course]);

  if (!course) return null;

  const totalModules = modules.length;
  const completedCount = completedModules.size;
  const progress = totalModules > 0 ? Math.round((completedCount / totalModules) * 100) : 0;
  const activeModule = modules[activeModuleIdx];

  const markComplete = async () => {
    const newCompleted = new Set([...completedModules, activeModuleIdx]);
    setCompletedModules(newCompleted);
    const newProgress = Math.round((newCompleted.size / totalModules) * 100);

    // Update assignment progress
    if (assignment?.id) {
      const newStatus = newProgress === 100 ? 'completed' : 'in_progress';
      await base44.entities.CourseAssignment.update(assignment.id, {
        progress_percentage: newProgress,
        status: newStatus,
        ...(newProgress === 100 ? { completed_at: new Date().toISOString() } : {}),
      });
      queryClient.invalidateQueries({ queryKey: ['courseAssignments'] });
      onProgressUpdate?.(newProgress);
    }

    // Auto-advance
    if (activeModuleIdx < totalModules - 1) {
      setTimeout(() => setActiveModuleIdx(i => i + 1), 400);
    }
  };

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', stiffness: 280, damping: 30 }}
      className="fixed top-0 right-0 h-full z-50 flex flex-col overflow-hidden shadow-2xl"
      style={{ width: 'min(900px, 100vw)', background: '#080b18', borderLeft: '1px solid rgba(139,92,246,0.20)' }}>
      {/* Header */}
      <div className="flex-shrink-0 p-5 flex items-center justify-between"
        style={{ borderBottom: '1px solid rgba(255,255,255,0.08)', background: 'rgba(139,92,246,0.08)' }}>
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: cat.bg, border: `1px solid ${cat.border}` }}>
            <BookOpen className="w-4 h-4" style={{ color: cat.text }} />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-white truncate">{course.title}</h2>
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.40)' }}>{course.category} · {formatDuration(course.duration_minutes)}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          {/* Progress */}
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-24 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.10)' }}>
              <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #8b5cf6, #22d3ee)' }} />
            </div>
            <span className="text-xs font-bold text-white">{progress}%</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-white/10 transition-colors" style={{ color: 'rgba(255,255,255,0.50)' }}>
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Module list sidebar */}
        <div className="w-56 flex-shrink-0 overflow-y-auto p-3 space-y-1" style={{ borderRight: '1px solid rgba(255,255,255,0.06)', background: 'rgba(0,0,0,0.20)' }}>
          <p className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 mb-2" style={{ color: 'rgba(255,255,255,0.35)' }}>Modules</p>
          {modules.map((mod, idx) => {
            const isDone = completedModules.has(idx);
            const isActive = activeModuleIdx === idx;
            return (
              <button key={idx} onClick={() => setActiveModuleIdx(idx)}
                className="w-full text-left px-3 py-2.5 rounded-xl transition-all text-xs"
                style={{
                  background: isActive ? 'rgba(139,92,246,0.20)' : 'transparent',
                  border: isActive ? '1px solid rgba(139,92,246,0.35)' : '1px solid transparent',
                  color: isDone ? '#34d399' : isActive ? '#c4b5fd' : 'rgba(255,255,255,0.55)',
                }}>
                <div className="flex items-center gap-2">
                  {isDone ? <CheckCircle2 className="w-3 h-3 flex-shrink-0 text-emerald-400" /> : <div className="w-3 h-3 rounded-full flex-shrink-0 border border-current opacity-50" />}
                  <span className="leading-snug line-clamp-2">{mod.title}</span>
                </div>
                {mod.type === 'quiz' && <span className="mt-1 text-[10px] text-purple-400 font-medium">Quiz</span>}
              </button>
            );
          })}
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeModule ? (
            <AnimatePresence mode="wait">
              <motion.div key={activeModuleIdx}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full"
                    style={{ background: 'rgba(139,92,246,0.20)', color: '#c4b5fd', border: '1px solid rgba(139,92,246,0.30)' }}>
                    {activeModule.type}
                  </span>
                  <span className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>
                    <Clock className="w-3 h-3 inline mr-1" />{formatDuration(activeModule.duration_minutes)}
                  </span>
                  <span className="text-xs ml-auto" style={{ color: 'rgba(255,255,255,0.35)' }}>
                    {activeModuleIdx + 1} / {totalModules}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white mb-4">{activeModule.title}</h2>

                {/* Content */}
                <div className="prose prose-invert prose-sm max-w-none" style={{ color: 'rgba(255,255,255,0.75)' }}>
                  {activeModule.content?.split('\n').map((line, i) => {
                    if (line.startsWith('## ')) return <h2 key={i} className="text-base font-bold text-white mt-4 mb-2">{line.slice(3)}</h2>;
                    if (line.startsWith('### ')) return <h3 key={i} className="text-sm font-bold text-purple-300 mt-3 mb-1">{line.slice(4)}</h3>;
                    if (line.startsWith('- ')) return <div key={i} className="flex items-start gap-2 mb-1.5"><span className="text-purple-400 mt-0.5">·</span><span className="text-sm">{line.slice(2)}</span></div>;
                    if (line.trim() === '') return <div key={i} className="h-2" />;
                    return <p key={i} className="text-sm mb-2 leading-relaxed">{line}</p>;
                  })}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 mt-8 pt-6" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
                  <button onClick={() => setActiveModuleIdx(i => Math.max(0, i - 1))}
                    disabled={activeModuleIdx === 0}
                    className="flex items-center gap-1.5 px-4 h-9 rounded-xl text-xs font-semibold transition-colors disabled:opacity-30"
                    style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.70)' }}>
                    <ChevronLeft className="w-3.5 h-3.5" /> Previous
                  </button>

                  {!completedModules.has(activeModuleIdx) ? (
                    <button onClick={markComplete}
                      className="flex items-center gap-1.5 px-5 h-9 rounded-xl text-xs font-bold text-white transition-all hover:opacity-90"
                      style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Mark Complete
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 px-4 h-9 rounded-xl text-xs font-semibold text-emerald-400"
                      style={{ background: 'rgba(16,185,129,0.10)', border: '1px solid rgba(16,185,129,0.25)' }}>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                    </div>
                  )}

                  {activeModuleIdx < totalModules - 1 && (
                    <button onClick={() => setActiveModuleIdx(i => i + 1)}
                      className="flex items-center gap-1.5 px-4 h-9 rounded-xl text-xs font-semibold ml-auto transition-colors"
                      style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.70)' }}>
                      Next <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Completion banner */}
                {progress === 100 && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    className="mt-6 rounded-2xl p-5 flex items-center gap-4"
                    style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.30)' }}>
                    <Award className="w-8 h-8 text-emerald-400 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-bold text-white">Course Complete!</p>
                      <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.55)' }}>
                        You've completed all modules. A certificate has been recorded.
                      </p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          ) : (
            <div className="flex items-center justify-center h-full text-white/30">
              <p className="text-sm">Select a module to begin.</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}