import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, GraduationCap, Sparkles, ChevronRight, PlayCircle, Clock } from 'lucide-react';
import { formatDuration } from './learningData';

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function LearningHeroSection({ user, inProgressCourse, inProgressAssignment, onContinue, onSearch, onAIAssistant }) {
  const [search, setSearch] = useState('');
  const firstName = user?.full_name?.split(' ')[0] || 'there';

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch(search);
  };

  const progress = inProgressAssignment?.progress_percentage || 0;

  return (
    <div className="relative overflow-hidden rounded-3xl mb-6"
      style={{
        background: 'linear-gradient(135deg, #0d0a1e 0%, #0f172a 40%, #0a0d1e 100%)',
        border: '1px solid rgba(139,92,246,0.25)',
        boxShadow: '0 0 60px rgba(139,92,246,0.15), 0 0 120px rgba(139,92,246,0.05)',
      }}>
      {/* Ambient glow blobs */}
      <div className="absolute top-0 left-0 w-72 h-72 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(139,92,246,0.20) 0%, transparent 70%)', filter: 'blur(40px)', transform: 'translate(-30%, -30%)' }} />
      <div className="absolute bottom-0 right-0 w-64 h-64 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(34,211,238,0.15) 0%, transparent 70%)', filter: 'blur(40px)', transform: 'translate(30%, 30%)' }} />
      <div className="absolute top-1/2 right-1/4 w-48 h-48 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(236,44,163,0.10) 0%, transparent 70%)', filter: 'blur(30px)' }} />

      <div className="relative z-10 p-6 lg:p-8">
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
          {/* Left: greeting + search */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold uppercase tracking-wider"
                style={{ background: 'rgba(139,92,246,0.20)', border: '1px solid rgba(139,92,246,0.35)', color: '#a78bfa' }}>
                <GraduationCap className="w-3 h-3" /> Learning Hub
              </div>
            </div>

            <h1 className="text-2xl lg:text-3xl font-bold text-white mb-1 leading-tight">
              {getGreeting()}, <span style={{ background: 'linear-gradient(90deg, #a78bfa, #22d3ee)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{firstName}</span>
            </h1>
            <p className="text-sm mb-5" style={{ color: 'rgba(255,255,255,0.55)' }}>
              Grow your skills, complete training and track your progress.
            </p>

            {/* Search */}
            <form onSubmit={handleSearch} className="relative max-w-lg">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(255,255,255,0.35)' }} />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search courses, training, certificates…"
                className="w-full pl-10 pr-4 h-10 rounded-xl text-sm text-white placeholder:text-white/35 outline-none focus:ring-1 focus:ring-purple-500/50"
                style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)' }}
              />
            </form>

            {/* AI CTA */}
            <button onClick={onAIAssistant}
              className="mt-4 flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, rgba(139,92,246,0.30), rgba(236,44,163,0.20))', border: '1px solid rgba(139,92,246,0.35)', color: '#c4b5fd' }}>
              <Sparkles className="w-3.5 h-3.5" />
              Ask AI Learning Assistant
            </button>
          </div>

          {/* Right: Continue Learning card */}
          <div className="lg:w-72 flex-shrink-0">
            {inProgressCourse ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="rounded-2xl p-5 h-full flex flex-col justify-between"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <PlayCircle className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider">Continue Learning</span>
                  </div>
                  <h3 className="text-sm font-bold text-white mb-1 leading-snug">{inProgressCourse.title}</h3>
                  <p className="text-xs mb-3" style={{ color: 'rgba(255,255,255,0.45)' }}>{inProgressCourse.category}</p>
                  <div className="flex items-center gap-2 text-xs mb-3" style={{ color: 'rgba(255,255,255,0.45)' }}>
                    <Clock className="w-3 h-3" />
                    <span>{formatDuration(inProgressCourse.duration_minutes)}</span>
                    <span>·</span>
                    <span>{inProgressCourse.modules_count} modules</span>
                  </div>
                  {/* Progress bar */}
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-xs text-purple-300">Progress</span>
                    <span className="text-xs font-bold text-white">{progress}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full mb-4" style={{ background: 'rgba(255,255,255,0.10)' }}>
                    <div className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #8b5cf6, #22d3ee)' }} />
                  </div>
                </div>
                <button onClick={() => onContinue(inProgressCourse)}
                  className="flex items-center justify-center gap-2 w-full h-9 rounded-xl text-xs font-bold text-white transition-all hover:opacity-90"
                  style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
                  Continue Course <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            ) : (
              <div className="rounded-2xl p-5 flex flex-col items-center justify-center text-center h-full min-h-[140px]"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px dashed rgba(255,255,255,0.12)' }}>
                <GraduationCap className="w-8 h-8 mb-2" style={{ color: 'rgba(139,92,246,0.5)' }} />
                <p className="text-xs font-medium text-white/60">No course in progress</p>
                <p className="text-xs text-white/30 mt-1">Browse the library to get started</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}