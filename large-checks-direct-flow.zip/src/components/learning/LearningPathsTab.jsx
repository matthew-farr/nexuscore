import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, X, Clock, Layers, CheckCircle2, BookOpen, Rocket, TrendingUp, Shield, Users2, Settings2, Star } from 'lucide-react';
import { formatDuration } from './learningData';

const ICON_MAP = { Rocket, TrendingUp, Shield, Users2, Settings2, Star, BookOpen };

function PathCard({ path, onView, index }) {
  const Icon = ICON_MAP[path.icon] || BookOpen;
  const colour = path.colour || '#8b5cf6';
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      className="rounded-2xl overflow-hidden cursor-pointer group transition-all duration-200 hover:scale-[1.012]"
      style={{ background: 'linear-gradient(145deg, rgba(255,255,255,0.06), rgba(255,255,255,0.03))', border: '1px solid rgba(255,255,255,0.09)' }}
      onClick={() => onView(path)}>
      {/* Colour top bar */}
      <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, ${colour}, ${colour}66)` }} />
      <div className="p-5">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: `${colour}22`, border: `1px solid ${colour}40` }}>
            <Icon className="w-5 h-5" style={{ color: colour }} />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold text-white leading-snug">{path.title}</h3>
            <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.45)' }}>{path.category}</p>
          </div>
        </div>
        <p className="text-xs leading-relaxed mb-4 line-clamp-2" style={{ color: 'rgba(255,255,255,0.50)' }}>{path.description}</p>
        <div className="flex items-center gap-4 text-xs mb-4" style={{ color: 'rgba(255,255,255,0.40)' }}>
          <span className="flex items-center gap-1"><Layers className="w-3 h-3" />{path.courses_count} courses</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{formatDuration(path.estimated_duration_minutes)}</span>
        </div>
        <button className="w-full flex items-center justify-center gap-1.5 h-8 rounded-xl text-xs font-semibold transition-all hover:opacity-90"
          style={{ background: `${colour}22`, border: `1px solid ${colour}40`, color: colour }}>
          View Path <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </motion.div>
  );
}

function PathDetailDrawer({ path, courses, onClose }) {
  if (!path) return null;
  const colour = path.colour || '#8b5cf6';
  const Icon = ICON_MAP[path.icon] || BookOpen;

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', stiffness: 280, damping: 30 }}
      className="fixed top-0 right-0 h-full z-50 flex flex-col shadow-2xl overflow-hidden"
      style={{ width: 'min(520px, 100vw)', background: '#080b18', borderLeft: '1px solid rgba(255,255,255,0.08)' }}>
      <div className="flex-shrink-0 p-6 flex items-start justify-between"
        style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${colour}22`, border: `1px solid ${colour}40` }}>
            <Icon className="w-5 h-5" style={{ color: colour }} />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">{path.title}</h2>
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.45)' }}>{path.courses_count} courses · {formatDuration(path.estimated_duration_minutes)}</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 rounded-xl hover:bg-white/10" style={{ color: 'rgba(255,255,255,0.50)' }}>
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-6">
        <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.60)' }}>{path.description}</p>
        <p className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: 'rgba(255,255,255,0.35)' }}>Courses in this path</p>
        <div className="space-y-2">
          {courses.slice(0, path.courses_count || 4).map((c, i) => (
            <div key={c.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0" style={{ background: `${colour}22`, color: colour }}>{i + 1}</div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-white truncate">{c.title}</p>
                <p className="text-[10px]" style={{ color: 'rgba(255,255,255,0.35)' }}>{c.category} · {formatDuration(c.duration_minutes)}</p>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">Required</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export default function LearningPathsTab({ paths, courses }) {
  const [selectedPath, setSelectedPath] = useState(null);

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {paths.map((p, i) => (
          <PathCard key={p.id || i} path={p} onView={setSelectedPath} index={i} />
        ))}
        {paths.length === 0 && (
          <div className="col-span-full text-center py-16">
            <p className="text-white/40 text-sm">No learning paths available.</p>
          </div>
        )}
      </div>
      <AnimatePresence>
        {selectedPath && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
              onClick={() => setSelectedPath(null)} />
            <PathDetailDrawer path={selectedPath} courses={courses} onClose={() => setSelectedPath(null)} />
          </>
        )}
      </AnimatePresence>
    </div>
  );
}