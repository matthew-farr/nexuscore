import { useState, useMemo } from 'react';
import { Search, ChevronRight, AlertTriangle } from 'lucide-react';
import { STATUS_STYLES, PRIORITY_STYLES, formatDuration, isOverdue, daysUntil } from './learningData';

const EMPTY = '—';

export default function AssignedTrainingTab({ courses, assignments, onView }) {
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [search, setSearch] = useState('');

  const rows = useMemo(() => {
    return assignments
      .map(a => {
        const course = courses.find(c => c.id === a.course_id);
        if (!course) return null;
        const overdue = isOverdue(a.due_date) && a.status !== 'completed';
        const status = overdue ? 'overdue' : a.status;
        return { ...a, course, status };
      })
      .filter(Boolean)
      .filter(r => {
        if (statusFilter !== 'all' && r.status !== statusFilter) return false;
        if (priorityFilter !== 'all' && r.priority !== priorityFilter) return false;
        if (search) {
          const q = search.toLowerCase();
          if (!r.course.title.toLowerCase().includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        const pOrder = { mandatory: 0, high: 1, medium: 2, low: 3 };
        return (pOrder[a.priority] ?? 3) - (pOrder[b.priority] ?? 3);
      });
  }, [courses, assignments, statusFilter, priorityFilter, search]);

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: 'rgba(255,255,255,0.30)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search assigned…"
            className="pl-9 pr-3 h-8 rounded-xl text-xs text-white placeholder:text-white/30 outline-none w-44"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }} />
        </div>
        {[
          { label: 'Status', value: statusFilter, set: setStatusFilter, opts: ['all', 'not_started', 'in_progress', 'completed', 'overdue'] },
          { label: 'Priority', value: priorityFilter, set: setPriorityFilter, opts: ['all', 'mandatory', 'high', 'medium', 'low'] },
        ].map(f => (
          <select key={f.label} value={f.value} onChange={e => f.set(e.target.value)}
            className="h-8 px-3 rounded-xl text-xs outline-none"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', color: 'rgba(255,255,255,0.70)' }}>
            {f.opts.map(o => <option key={o} value={o} style={{ background: '#0f172a' }}>{o === 'all' ? `All ${f.label}s` : o.replace('_', ' ')}</option>)}
          </select>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="text-center py-16"><p className="text-white/40 text-sm">No assigned training found.</p></div>
      ) : (
        <div className="space-y-2">
          {rows.map((row, i) => {
            const statusStyle = STATUS_STYLES[row.status] || STATUS_STYLES.not_started;
            const priorityStyle = PRIORITY_STYLES[row.priority] || PRIORITY_STYLES.medium;
            const days = daysUntil(row.due_date);
            return (
              <div key={row.id || i}
                className="flex flex-col sm:flex-row sm:items-center gap-3 px-4 py-3 rounded-2xl transition-all hover:bg-white/5 cursor-pointer"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                onClick={() => onView(row.course)}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold text-white truncate">{row.course.title}</p>
                    {row.status === 'overdue' && <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />}
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.40)' }}>
                    {row.course.category} · {formatDuration(row.course.duration_minutes)}
                    {row.assigned_by && ` · Assigned by ${row.assigned_by}`}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-wrap flex-shrink-0">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${priorityStyle.cls}`}>{priorityStyle.label}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${statusStyle.cls}`}>{statusStyle.label}</span>
                  {row.due_date && (
                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                      style={{ background: days !== null && days < 7 ? 'rgba(239,68,68,0.15)' : 'rgba(255,255,255,0.06)', color: days !== null && days < 7 ? '#f87171' : 'rgba(255,255,255,0.50)', border: '1px solid rgba(255,255,255,0.10)' }}>
                      Due {new Date(row.due_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                    </span>
                  )}
                  {/* Progress */}
                  <div className="hidden sm:flex items-center gap-2">
                    <div className="w-16 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                      <div className="h-full rounded-full" style={{ width: `${row.progress_percentage || 0}%`, background: 'linear-gradient(90deg, #8b5cf6, #22d3ee)' }} />
                    </div>
                    <span className="text-xs text-white/50">{row.progress_percentage || 0}%</span>
                  </div>
                  <ChevronRight className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.25)' }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}