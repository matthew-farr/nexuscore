import { motion } from 'framer-motion';
import { Clock, Layers, ChevronRight, Star } from 'lucide-react';
import { CATEGORY_COLOURS, DIFFICULTY_STYLES, STATUS_STYLES, formatDuration } from './learningData';

export default function CourseCard({ course, assignment, onView, index = 0, compact = false }) {
  const cat = CATEGORY_COLOURS[course.category] || CATEGORY_COLOURS['Operations'];
  const diff = DIFFICULTY_STYLES[course.difficulty] || DIFFICULTY_STYLES.Beginner;
  const status = assignment ? STATUS_STYLES[assignment.status] : null;
  const progress = assignment?.progress_percentage || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.04, 0.25) }}
      className="rounded-2xl flex flex-col overflow-hidden group transition-all duration-200 hover:scale-[1.012] cursor-pointer"
      style={{
        background: 'linear-gradient(145deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.03) 100%)',
        border: '1px solid rgba(255,255,255,0.09)',
        boxShadow: '0 4px 24px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.06)',
        backdropFilter: 'blur(20px)',
      }}
      onClick={() => onView(course)}
    >
      {/* Category header strip */}
      <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, ${cat.text}, ${cat.text}66)` }} />

      <div className="p-4 flex-1 flex flex-col">
        {/* Category + difficulty */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full border" style={{ color: cat.text, background: cat.bg, borderColor: cat.border }}>
            {course.category}
          </span>
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${diff.cls}`}>
            {course.difficulty}
          </span>
          {status && (
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ml-auto ${status.cls}`}>
              {status.label}
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="text-sm font-bold text-white leading-snug mb-1.5 flex-1">{course.title}</h3>

        {!compact && course.description && (
          <p className="text-xs leading-relaxed mb-3 line-clamp-2" style={{ color: 'rgba(255,255,255,0.45)' }}>
            {course.description}
          </p>
        )}

        {/* Meta */}
        <div className="flex items-center gap-3 text-xs mb-3" style={{ color: 'rgba(255,255,255,0.40)' }}>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{formatDuration(course.duration_minutes)}</span>
          <span className="flex items-center gap-1"><Layers className="w-3 h-3" />{course.modules_count} modules</span>
        </div>

        {/* Progress bar if assigned */}
        {assignment && (
          <div className="mb-3">
            <div className="flex items-center justify-between text-xs mb-1">
              <span style={{ color: 'rgba(255,255,255,0.40)' }}>Progress</span>
              <span className="font-semibold text-white">{progress}%</span>
            </div>
            <div className="w-full h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${progress}%`, background: progress === 100 ? 'linear-gradient(90deg, #10b981, #34d399)' : 'linear-gradient(90deg, #8b5cf6, #22d3ee)' }} />
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 pb-4">
        <button className="w-full flex items-center justify-center gap-1.5 h-8 rounded-xl text-xs font-semibold text-white transition-all hover:opacity-90"
          style={{ background: assignment?.status === 'completed' ? 'rgba(16,185,129,0.20)' : 'linear-gradient(135deg, #8b5cf6, #6366f1)', border: assignment?.status === 'completed' ? '1px solid rgba(16,185,129,0.30)' : 'none' }}
          onClick={e => { e.stopPropagation(); onView(course); }}>
          {assignment?.status === 'completed' ? 'View Course' : assignment?.status === 'in_progress' ? 'Continue' : 'Start Course'}
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </motion.div>
  );
}