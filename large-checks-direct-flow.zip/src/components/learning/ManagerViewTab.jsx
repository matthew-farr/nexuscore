import { motion } from 'framer-motion';
import { Users2, AlertTriangle, Award, BookOpen, ChevronRight, UserPlus } from 'lucide-react';

// Mock team data for demo
const MOCK_TEAM = [
  { name: 'Sarah Johnson',   dept: 'Operations',   assigned: 5, completed: 4, overdue: 0, progress: 82, last: '2 days ago' },
  { name: 'James Wilson',    dept: 'Sales',         assigned: 4, completed: 2, overdue: 1, progress: 55, last: '1 week ago' },
  { name: 'Emily Clarke',    dept: 'Customer Svc',  assigned: 3, completed: 3, overdue: 0, progress: 100, last: 'Today' },
  { name: 'Tom Hartley',     dept: 'Operations',   assigned: 6, completed: 1, overdue: 2, progress: 22, last: '3 weeks ago' },
  { name: 'Priya Patel',     dept: 'Compliance',   assigned: 4, completed: 4, overdue: 0, progress: 100, last: 'Yesterday' },
  { name: 'Daniel Foster',   dept: 'Sales',         assigned: 3, completed: 0, overdue: 3, progress: 0,   last: 'Never' },
];

export default function ManagerViewTab({ user }) {
  const isManager = ['admin', 'manager', 'super_admin'].includes(user?.role);

  if (!isManager) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
          style={{ background: 'rgba(139,92,246,0.10)', border: '1px solid rgba(139,92,246,0.20)' }}>
          <Users2 className="w-7 h-7" style={{ color: 'rgba(139,92,246,0.50)' }} />
        </div>
        <p className="text-white/50 text-sm font-medium">Manager access required</p>
        <p className="text-white/25 text-xs mt-1">This view is only available to managers and admins.</p>
      </div>
    );
  }

  const teamCompletion = Math.round(MOCK_TEAM.reduce((s, m) => s + m.progress, 0) / MOCK_TEAM.length);
  const overdueCount = MOCK_TEAM.reduce((s, m) => s + m.overdue, 0);
  const completedAll = MOCK_TEAM.filter(m => m.progress === 100).length;

  const kpis = [
    { label: 'Team Completion',    value: `${teamCompletion}%`, icon: BookOpen,       colour: '#8b5cf6' },
    { label: 'Overdue Training',   value: overdueCount,         icon: AlertTriangle,  colour: '#ef4444' },
    { label: 'Fully Completed',    value: completedAll,         icon: Award,          colour: '#10b981' },
    { label: 'Team Members',       value: MOCK_TEAM.length,     icon: Users2,         colour: '#22d3ee' },
  ];

  return (
    <div>
      {/* KPI strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {kpis.map((k, i) => {
          const Icon = k.icon;
          return (
            <motion.div key={k.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="rounded-2xl p-4"
              style={{ background: `${k.colour}15`, border: `1.5px solid ${k.colour}30` }}>
              <div className="w-8 h-8 rounded-xl flex items-center justify-center mb-2" style={{ background: `${k.colour}22` }}>
                <Icon className="w-4 h-4" style={{ color: k.colour }} />
              </div>
              <p className="text-2xl font-extrabold text-white">{k.value}</p>
              <p className="text-xs font-medium mt-0.5" style={{ color: 'rgba(255,255,255,0.50)' }}>{k.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Actions */}
      <div className="flex gap-3 mb-6 flex-wrap">
        {['Assign Course', 'Assign Learning Path', 'Send Reminder'].map(action => (
          <button key={action}
            className="flex items-center gap-2 px-4 h-9 rounded-xl text-xs font-semibold transition-all hover:opacity-80"
            style={{ background: 'rgba(139,92,246,0.20)', border: '1px solid rgba(139,92,246,0.35)', color: '#c4b5fd' }}>
            <UserPlus className="w-3.5 h-3.5" /> {action}
          </button>
        ))}
      </div>

      {/* Team table */}
      <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="px-4 py-3" style={{ background: 'rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          <h3 className="text-sm font-bold text-white">Team Progress</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                {['Staff Member', 'Department', 'Assigned', 'Completed', 'Overdue', 'Progress', 'Last Active'].map(h => (
                  <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-wider px-4 py-3"
                    style={{ color: 'rgba(255,255,255,0.35)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MOCK_TEAM.map((member, i) => (
                <tr key={i} className="transition-colors hover:bg-white/5 cursor-pointer"
                  style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 text-white"
                        style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}>
                        {member.name.charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-white whitespace-nowrap">{member.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'rgba(255,255,255,0.50)' }}>{member.dept}</td>
                  <td className="px-4 py-3 text-xs text-white font-medium">{member.assigned}</td>
                  <td className="px-4 py-3 text-xs text-emerald-400 font-medium">{member.completed}</td>
                  <td className="px-4 py-3">
                    {member.overdue > 0
                      ? <span className="text-xs font-semibold text-red-400 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{member.overdue}</span>
                      : <span className="text-xs text-white/30">—</span>}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                        <div className="h-full rounded-full" style={{ width: `${member.progress}%`, background: member.progress === 100 ? 'linear-gradient(90deg,#10b981,#34d399)' : 'linear-gradient(90deg,#8b5cf6,#22d3ee)' }} />
                      </div>
                      <span className="text-xs text-white font-semibold">{member.progress}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'rgba(255,255,255,0.40)' }}>{member.last}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}