import { useState, useMemo } from 'react';
import { Calendar, Copy, RotateCcw, Check } from 'lucide-react';
import { format, addDays, subDays, differenceInDays } from 'date-fns';
import { useTheme } from '../../ThemeProvider';
import { toast } from 'sonner';

export default function DateBetween({ onDateRangeChange, isDark: propIsDark, accentColor }) {
  const { theme } = useTheme();
  const isDark = propIsDark !== undefined ? propIsDark : theme === 'dark';
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(today);
  const [daysBefore, setDaysBefore] = useState('');
  const [daysAfter, setDaysAfter] = useState('');
  const [copied, setCopied] = useState(false);

  const calculationType = useMemo(() => {
    if (daysBefore) return 'Days Before';
    if (daysAfter) return 'Days After';
    return 'Manual';
  }, [daysBefore, daysAfter]);

  // Calculate Start Date when Days Before changes
  const handleDaysBeforeChange = (value) => {
    setDaysBefore(value);
    setDaysAfter(''); // Clear Days After
    
    if (value && !isNaN(value)) {
      const calculated = subDays(endDate, parseInt(value));
      setStartDate(calculated);
    } else {
      setStartDate(null);
    }
  };

  // Calculate End Date when Days After changes
  const handleDaysAfterChange = (value) => {
    setDaysAfter(value);
    setDaysBefore(''); // Clear Days Before
    
    if (value && !isNaN(value) && startDate) {
      const calculated = addDays(startDate, parseInt(value));
      setEndDate(calculated);
    }
  };

  // Handle manual Start Date change
  const handleStartDateChange = (e) => {
    const dateStr = e.target.value;
    if (dateStr) {
      const date = new Date(dateStr);
      date.setHours(0, 0, 0, 0);
      setStartDate(date);
      setDaysBefore('');
      setDaysAfter('');
    }
  };

  // Handle manual End Date change
  const handleEndDateChange = (e) => {
    const dateStr = e.target.value;
    if (dateStr) {
      const date = new Date(dateStr);
      date.setHours(0, 0, 0, 0);
      setEndDate(date);
      setDaysBefore('');
      setDaysAfter('');
    }
  };

  // Calculate total days
  const totalDays = useMemo(() => {
    if (!startDate || !endDate) return 0;
    return differenceInDays(endDate, startDate);
  }, [startDate, endDate]);

  // Clear all
  const handleClear = () => {
    setStartDate(null);
    setEndDate(today);
    setDaysBefore('');
    setDaysAfter('');
  };

  // Copy result
  const handleCopy = () => {
    const result = `Start: ${startDate ? format(startDate, 'dd MMM yyyy') : 'N/A'}, End: ${format(endDate, 'dd MMM yyyy')}, Days: ${totalDays}`;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Date range copied');
  };

  // Notify parent of date range changes
  if (onDateRangeChange) {
    onDateRangeChange({
      startDate,
      endDate,
      totalDays,
      calculationType,
    });
  }

  const formatDateForInput = (date) => {
    if (!date) return '';
    return format(date, 'yyyy-MM-dd');
  };

  const glassStyle = {
    background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.7)',
    border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.3)'}`,
    backdropFilter: 'blur(20px)',
  };

  return (
    <div className={`rounded-xl space-y-6 ${isDark ? '' : ''}`}>
      {/* Helper text */}
      <div className={`text-xs leading-relaxed ${isDark ? 'text-white/50' : 'text-slate-600'}`} style={{ color: isDark ? 'rgba(255,255,255,0.48)' : 'rgba(0,0,0,0.50)' }}>
        <p><strong>Set an End Date (defaults to today), then choose Start Date manually, or use Days Before/After to auto-calculate.</strong></p>
      </div>

      {/* End Date */}
      <div>
        <label style={{ color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)' }} className={`block text-sm font-semibold mb-2`}>
          End Date
        </label>
        <input
          type="date"
          value={formatDateForInput(endDate)}
          onChange={handleEndDateChange}
          className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
          style={{...glassStyle, color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)'}}
        />
        <p style={{ color: isDark ? 'rgba(255,255,255,0.40)' : 'rgba(0,0,0,0.45)' }} className={`text-xs mt-1`}>
          {endDate && format(endDate, 'EEEE, dd MMMM yyyy')}
        </p>
      </div>

      {/* Start Date */}
      <div>
        <label style={{ color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)' }} className={`block text-sm font-semibold mb-2`}>
          Start Date
        </label>
        <input
          type="date"
          value={formatDateForInput(startDate)}
          onChange={handleStartDateChange}
          className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
          style={{...glassStyle, color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)'}}
        />
        <p style={{ color: isDark ? 'rgba(255,255,255,0.40)' : 'rgba(0,0,0,0.45)' }} className={`text-xs mt-1`}>
          {startDate ? format(startDate, 'EEEE, dd MMMM yyyy') : 'Not set'}
        </p>
      </div>

      {/* Days Before / Days After */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label style={{ color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)' }} className={`block text-sm font-semibold mb-2`}>
            Days Before
          </label>
          <input
            type="number"
            min="0"
            value={daysBefore}
            onChange={(e) => handleDaysBeforeChange(e.target.value)}
            placeholder="e.g. 30"
            className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
            style={{...glassStyle, color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)'}}
          />
          <p style={{ color: isDark ? 'rgba(255,255,255,0.40)' : 'rgba(0,0,0,0.45)' }} className={`text-xs mt-1`}>
            Subtract days from End Date
          </p>
        </div>

        <div>
          <label style={{ color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)' }} className={`block text-sm font-semibold mb-2`}>
            Days After
          </label>
          <input
            type="number"
            min="0"
            value={daysAfter}
            onChange={(e) => handleDaysAfterChange(e.target.value)}
            placeholder="e.g. 30"
            className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
            style={{...glassStyle, color: isDark ? 'rgba(255,255,255,0.88)' : 'hsl(230 25% 15%)'}}
            disabled={!startDate}
          />
          <p style={{ color: isDark ? 'rgba(255,255,255,0.40)' : 'rgba(0,0,0,0.45)' }} className={`text-xs mt-1`}>
            Add days to Start Date
          </p>
        </div>
      </div>

      {/* Results */}
      <div
        className="rounded-xl p-4 space-y-3"
        style={{
          background: 'linear-gradient(135deg, rgba(124,58,237,0.15), rgba(236,44,163,0.15))',
          border: '1px solid rgba(124,58,237,0.3)',
        }}
      >
        <div className="flex items-center justify-between">
          <span className={`text-xs font-semibold ${isDark ? 'text-white/70' : 'text-slate-600'}`}>
            CALCULATED RANGE
          </span>
          <span className={`text-xs px-2 py-1 rounded-full font-semibold ${
            isDark ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-700'
          }`}>
            {calculationType}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <p className={`text-xs ${isDark ? 'text-white/50' : 'text-slate-500'}`}>Start</p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
              {startDate ? format(startDate, 'dd MMM') : '—'}
            </p>
          </div>
          <div>
            <p className={`text-xs ${isDark ? 'text-white/50' : 'text-slate-500'}`}>End</p>
            <p className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
              {format(endDate, 'dd MMM')}
            </p>
          </div>
          <div>
            <p className={`text-xs ${isDark ? 'text-white/50' : 'text-slate-500'}`}>Days</p>
            <p className="text-sm font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {totalDays}
            </p>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2">
        <button
          onClick={handleCopy}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all"
          style={{
            background: 'linear-gradient(135deg, #7c3aed, #ec2ca3)',
            color: 'white',
          }}
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied!' : 'Copy Result'}
        </button>
        <button
          onClick={handleClear}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
          style={glassStyle}
        >
          <RotateCcw className="w-4 h-4" />
          Clear
        </button>
      </div>
    </div>
  );
}