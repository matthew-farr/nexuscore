import { useState } from "react";

const TIERS = [
  { label: "Tier 1: 3%", rate: 0.03 },
  { label: "Tier 2: 5%", rate: 0.05 },
  { label: "Tier 3: 7%", rate: 0.07 },
];

export default function CommissionEstimator({ isDark, accentColor }) {
  const [monthlyGP, setMonthlyGP] = useState("");
  const [tierIdx, setTierIdx] = useState(0);

  const gp = parseFloat(monthlyGP) || 0;
  const rate = TIERS[tierIdx].rate;
  const commission = gp * rate;

  const inputStyle = {
    width: "100%", height: "40px", borderRadius: "10px", padding: "0 12px", fontSize: "13px",
    background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)",
    border: isDark ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.10)",
    color: isDark ? "rgba(255,255,255,0.85)" : "hsl(230 25% 15%)", outline: "none",
  };
  const label = (text) => (
    <label style={{ fontSize: "11px", fontWeight: 600, display: "block", marginBottom: "4px", color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>{text}</label>
  );

  return (
    <div className="space-y-4">
      <div>
        {label("Monthly Gross Profit (£)")}
        <input type="number" placeholder="0.00" value={monthlyGP} onChange={e => setMonthlyGP(e.target.value)} style={inputStyle} />
      </div>
      <div>
        {label("Commission Tier")}
        <div className="grid grid-cols-3 gap-2 mt-1">
          {TIERS.map((t, i) => (
            <button
              key={i}
              onClick={() => setTierIdx(i)}
              className="rounded-xl py-2 text-xs font-semibold transition-all duration-150"
              style={{
                background: tierIdx === i ? `${accentColor}20` : (isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)"),
                border: `1px solid ${tierIdx === i ? accentColor + "45" : (isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)")}`,
                color: tierIdx === i ? accentColor : (isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.55)"),
                cursor: "pointer",
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="rounded-xl p-4 space-y-2" style={{ background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)", border: isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.06)" }}>
        {[
          { label: "Monthly GP", value: `£${gp.toFixed(2)}` },
          { label: "Commission Rate", value: `${(rate * 100).toFixed(0)}%` },
        ].map(({ label: l, value: v }, i) => (
          <div key={i} className="flex justify-between pb-2" style={{ borderBottom: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.05)" }}>
            <span style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.50)" }}>{l}</span>
            <span style={{ fontSize: "13px", fontWeight: 500, color: isDark ? "rgba(255,255,255,0.82)" : "hsl(230 25% 15%)" }}>{v}</span>
          </div>
        ))}
        <div className="flex justify-between pt-0.5">
          <span style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)" }}>Estimated Commission for Period</span>
          <span style={{ fontSize: "16px", fontWeight: 800, color: accentColor }}>£{(commission * 12).toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}