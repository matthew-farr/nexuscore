import { useState, useEffect, useMemo } from "react";
import { X, Plus, Trash2, Copy, Check, Download, Eye, EyeOff, Search, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { jsPDF } from "jspdf";
import { renderTemplate, getDefaultTemplate } from "@/lib/templateUtils";

const OVERSEAS_CHECK_TYPES = [
  { key: "financial_integrity", label: "Financial Integrity" },
  { key: "criminal_history", label: "Criminal History" },
  { key: "directorship", label: "Directorship" },
];

const CERTN_FLAG = {
  financial_integrity: "is_certn_fi",
  criminal_history: "is_certn_ch",
  directorship: "is_certn_dir",
};

const fmt = (n) => `£${(isFinite(n) ? n : 0).toFixed(2)}`;

export default function CustomerPriceListBuilder({ isDark, accentColor }) {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [overseas, setOverseas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);

  // Get today's date in YYYY-MM-DD format
  const todayDate = new Date().toISOString().split("T")[0];
  const thirtyDaysLater = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

  // Compute Prepared By from user profile
  const preparedByName = useMemo(() => {
    if (!userProfile) return user?.email || "";
    if (userProfile.display_name) return userProfile.display_name;
    if (userProfile.first_name && userProfile.last_name) return `${userProfile.first_name} ${userProfile.last_name}`;
    return userProfile.email || user?.email || "";
  }, [userProfile, user]);

  const [customerName, setCustomerName] = useState("");
  const [quoteDate, setQuoteDate] = useState(todayDate);
  const [validUntil, setValidUntil] = useState(thirtyDaysLater);
  const [lineItems, setLineItems] = useState([]);
  const [showInternal, setShowInternal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [proposalTheme, setProposalTheme] = useState("light");

  // Product selection state
  const [selectedProduct, setSelectedProduct] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedCheckType, setSelectedCheckType] = useState("criminal_history");
  const [serviceFee, setServiceFee] = useState("");
  const [customerNote, setCustomerNote] = useState("");
  const [internalNote, setInternalNote] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showProductDropdown, setShowProductDropdown] = useState(false);

  // Load pricing data and user profile
  useEffect(() => {
    Promise.all([
      base44.entities.PricingProduct.filter({ is_active: true }, "display_order", 500),
      base44.entities.OverseasPricingRate.filter({ is_active: true }, "country", 500),
      user ? base44.entities.UserProfile.filter({ auth_user_id: user.id }, "", 1).then(profiles => profiles?.[0] || null) : Promise.resolve(null),
    ]).then(([prods, overs, profile]) => {
      setProducts(prods);
      setOverseas(overs);
      if (profile) setUserProfile(profile);
      setLoading(false);
    }).catch(() => {
      setLoading(false);
    });
  }, [user]);

  const countries = useMemo(() => {
    const byName = {};
    for (const o of overseas) {
      const norm = String(o.country || "").toLowerCase().trim();
      if (!byName[norm] || new Date(o.last_updated || o.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
        byName[norm] = o;
      }
    }
    return Object.keys(byName).sort();
  }, [overseas]);

  const filteredProducts = useMemo(() => {
    const list = products.filter(p => p.product_name.toLowerCase().includes(searchQuery.toLowerCase()));
    if (selectedProduct) {
      const sel = list.find(p => p.product_name === selectedProduct);
      const rest = list.filter(p => p.product_name !== selectedProduct);
      return sel ? [sel, ...rest] : list;
    }
    return list;
  }, [products, searchQuery, selectedProduct]);

  const product = products.find(p => p.product_name === selectedProduct);
  const isOverseas = product?.product_type === "Overseas";

  // Calculate pricing for a product
  const calculatePrice = (prod, svcFee, country = null, checkType = null) => {
    if (!prod) return null;

    let supplierCostEx = prod.supplier_cost_ex_vat ?? 0;
    let supplierVatRate = prod.supplier_vat_rate ?? 0;

    // Override for overseas
    if (isOverseas && country && checkType) {
      const normCountry = String(country || "").toLowerCase().trim();
      const byName = {};
      for (const o of overseas) {
        const norm = String(o.country || "").toLowerCase().trim();
        if (norm === normCountry) {
          if (!byName[norm] || new Date(o.last_updated || o.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
            byName[norm] = o;
          }
        }
      }
      const overseasRecord = byName[normCountry];
      if (overseasRecord) {
        const certnFlag = CERTN_FLAG[checkType];
        if (certnFlag && overseasRecord[certnFlag]) {
          return { isCertn: true };
        }
        const costVal = overseasRecord[`${checkType}_cost`];
        if (!costVal || costVal <= 0) {
          return { notAvailable: true };
        }
        supplierCostEx = costVal;
        supplierVatRate = overseasRecord.vat_rate ?? 0.2;
      }
    }

    const svcFeeEx = parseFloat(svcFee) || 0;
    const serviceFeeVatRate = prod.service_fee_vat_rate ?? 0.2;

    const supplierCostInc = supplierCostEx * (1 + supplierVatRate);
    const serviceFeeInc = svcFeeEx * (1 + serviceFeeVatRate);
    const customerPriceEx = supplierCostEx + svcFeeEx;
    const customerPriceInc = supplierCostInc + serviceFeeInc;
    const margin = customerPriceEx > 0 ? svcFeeEx / customerPriceEx : 0;

    return {
      supplierCostEx,
      supplierVatRate,
      supplierCostInc,
      supplierVatAmount: supplierCostInc - supplierCostEx,
      svcFeeEx,
      serviceFeeVatRate,
      serviceFeeInc,
      serviceFeeVatAmount: serviceFeeInc - svcFeeEx,
      customerPriceEx,
      customerPriceInc,
      totalVatAmount: customerPriceInc - customerPriceEx,
      margin,
    };
  };

  const handleAddProduct = () => {
    if (!product || !serviceFee) {
      alert("Please select a product and enter service fee");
      return;
    }

    if (isOverseas && !selectedCountry) {
      alert("Please select a country");
      return;
    }

    const pricing = calculatePrice(product, serviceFee, selectedCountry, selectedCheckType);
    if (pricing?.isCertn) {
      alert("This check is handled via CERTN — contact your team lead for a quote");
      return;
    }
    if (pricing?.notAvailable) {
      alert("This check is not available for the selected country");
      return;
    }

    const line = {
      id: Date.now(),
      productName: product.product_name,
      productType: product.product_type,
      country: selectedCountry || null,
      checkType: selectedCheckType || null,
      supplierCostEx: pricing.supplierCostEx,
      supplierVatRate: pricing.supplierVatRate,
      serviceFeeEx: parseFloat(serviceFee),
      serviceFeeVatRate: pricing.serviceFeeVatRate,
      customerPriceEx: pricing.customerPriceEx,
      customerPriceInc: pricing.customerPriceInc,
      customerNote,
      internalNote,
      ...pricing,
    };

    setLineItems([...lineItems, line]);
    setSelectedProduct("");
    setSelectedCountry("");
    setSelectedCheckType("criminal_history");
    setServiceFee("");
    setCustomerNote("");
    setInternalNote("");
    setSearchQuery("");
  };

  const handleRemoveLine = (id) => {
    setLineItems(lineItems.filter(l => l.id !== id));
  };

  const totalCustomerEx = lineItems.reduce((sum, l) => sum + (l.customerPriceEx || 0), 0);
  const totalCustomerInc = lineItems.reduce((sum, l) => sum + (l.customerPriceInc || 0), 0);
  const totalSupplierInc = lineItems.reduce((sum, l) => sum + (l.supplierCostInc || 0), 0);
  const totalServiceInc = lineItems.reduce((sum, l) => sum + (l.serviceFeeInc || 0), 0);
  const totalMargin = totalCustomerEx > 0 ? lineItems.reduce((sum, l) => sum + (l.svcFeeEx || 0), 0) / totalCustomerEx : 0;

  const copyCustomerList = () => {
    const lines = [
      `${customerName ? customerName + " — " : ""}Customer Price List`,
      "─".repeat(50),
      ...lineItems.map(l => {
        const label = l.country ? `${l.productName} (${l.country} — ${OVERSEAS_CHECK_TYPES.find(t => t.key === l.checkType)?.label})` : l.productName;
        return `${label} — ${fmt(l.customerPriceInc)}`;
      }),
      "─".repeat(50),
      `Total: ${fmt(totalCustomerInc)}`,
      ...(validUntil ? [`Valid until: ${validUntil}`] : []),
    ].join("\n");
    navigator.clipboard.writeText(lines);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const copyInternalBreakdown = () => {
    const lines = [
      "Internal Pricing Breakdown",
      "─".repeat(80),
      ...lineItems.map(l => [
        `${l.productName}${l.country ? ` (${l.country} — ${OVERSEAS_CHECK_TYPES.find(t => t.key === l.checkType)?.label})` : ""}`,
        `  Supplier: ${fmt(l.supplierCostEx)} ex VAT @ ${(l.supplierVatRate * 100).toFixed(0)}% = ${fmt(l.supplierCostInc)}`,
        `  Service Fee: ${fmt(l.svcFeeEx)} ex VAT @ ${(l.serviceFeeVatRate * 100).toFixed(0)}% = ${fmt(l.serviceFeeInc)}`,
        `  Customer Price: ${fmt(l.customerPriceEx)} ex VAT / ${fmt(l.customerPriceInc)} inc VAT`,
        `  Margin: ${(l.margin * 100).toFixed(1)}%`,
      ].join("\n")).join("\n"),
      "─".repeat(80),
      `Total Customer Price: ${fmt(totalCustomerInc)}`,
      `Total Margin: ${(totalMargin * 100).toFixed(1)}%`,
    ].join("\n");
    navigator.clipboard.writeText(lines);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const buildQuoteData = () => {
    const totalVat = totalCustomerInc - totalCustomerEx;
    const themeMode = proposalTheme === "light" ? "theme-light" : "theme-dark";
    return {
      customerName,
      issuedDate: new Date(quoteDate).toLocaleDateString("en-GB"),
      validUntil: validUntil ? new Date(validUntil).toLocaleDateString("en-GB") : "",
      preparedBy: preparedByName,
      accountManagerEmail: user?.email || "",
      accountManagerPhone: userProfile?.work_mobile || userProfile?.phone_number || "",
      quoteReference: "",
      totalEx: totalCustomerEx,
      totalVat,
      totalInc: totalCustomerInc,
      customerNotes: lineItems.map(l => l.customerNote).filter(Boolean).join("; ") || "",
      internalNotes: lineItems.map(l => l.internalNote).filter(Boolean).join("; ") || "",
      theme_mode: themeMode,
      lineItems: lineItems.map(l => {
        const serviceName = l.country ? `${l.productName} (${l.country} — ${OVERSEAS_CHECK_TYPES.find(t => t.key === l.checkType)?.label})` : l.productName;
        return {
          service: serviceName,
          description: l.customerNote || "",
          serviceFee: l.svcFeeEx,
          servicePrice: l.customerPriceInc,
          notes: l.internalNote || "",
        };
      }),
      checkTypeLabels: OVERSEAS_CHECK_TYPES.reduce((acc, t) => ({ ...acc, [t.key]: t.label }), {}),
    };
  };

  const exportPDF = async () => {
    try {
      // Load active template
      const templates = await base44.entities.PriceListTemplate.filter({ is_active: true }, "uploaded_date", 1);
      const templateRecord = templates?.[0];
      
      let htmlContent;
      if (templateRecord?.html_file_url) {
        // Fetch HTML from URL
        const response = await fetch(templateRecord.html_file_url);
        const activeTemplate = await response.text();
        const quoteData = buildQuoteData();
        htmlContent = renderTemplate(activeTemplate, quoteData, false);
      } else {
        // Use default template
        const quoteData = buildQuoteData();
        htmlContent = getDefaultTemplate(quoteData);
      }

      // Open print preview
      const printWindow = window.open("", "", "width=900,height=800");
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 500);
    } catch (err) {
      console.error("PDF export error:", err);
      alert("Failed to generate PDF. Using fallback...");
      const quoteData = buildQuoteData();
      const htmlContent = getDefaultTemplate(quoteData);
      const printWindow = window.open("", "", "width=900,height=800");
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 500);
    }
  };

  const surface = { background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.02)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)", borderRadius: "12px" };
  const labelColor = isDark ? "rgba(255,255,255,0.92)" : "rgba(0,0,0,0.70)";
  const helperColor = isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)";
  const dimColor = isDark ? "rgba(255,255,255,0.38)" : "rgba(0,0,0,0.38)";
  const textColor = isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 12%)";
  const inputSt = {
    width: "100%",
    height: "36px",
    borderRadius: "9px",
    padding: "0 10px",
    fontSize: "13px",
    background: isDark ? "rgba(255,255,255,0.08)" : "#ffffff",
    border: isDark ? "1px solid rgba(255,255,255,0.12)" : "1px solid rgba(0,0,0,0.12)",
    color: isDark ? "#ffffff" : "#000000",
    outline: "none",
  };
  const selectSt = { ...inputSt, colorScheme: isDark ? "dark" : "light", color: isDark ? "#ffffff" : "#000000" };
  const placeholderColor = isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.50)";

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 gap-3">
        <Loader2 style={{ width: "24px", height: "24px", color: accentColor, animation: "spin 1s linear infinite" }} />
        <p style={{ fontSize: "12px", color: dimColor }}>Loading pricing data…</p>
        <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div className="space-y-5 relative">
      {/* Electric blob effect */}
      <div
        style={{
          position: "absolute",
          top: "-200px",
          right: "-100px",
          width: "400px",
          height: "400px",
          borderRadius: "50%",
          background: "radial-gradient(ellipse at 30% 30%, #ec2ca3 0%, rgba(236, 44, 163, 0.3) 25%, transparent 70%), radial-gradient(ellipse at 70% 70%, #22d3ee 0%, rgba(34, 211, 238, 0.2) 25%, transparent 70%), radial-gradient(ellipse at 50% 50%, #0ea5e9 0%, rgba(14, 165, 233, 0.25) 30%, transparent 70%), radial-gradient(ellipse at 80% 20%, #7c3aed 0%, rgba(124, 58, 237, 0.2) 25%, transparent 70%)",
          filter: "blur(80px)",
          animation: "float 8s ease-in-out infinite",
          pointerEvents: "none",
          zIndex: 0,
        }}
      />
      <style>{`@keyframes float { 0%, 100% { transform: translateY(0px) translateX(0px); } 50% { transform: translateY(-30px) translateX(10px); } }`}</style>

      {/* Header */}
      <div style={{ position: "relative", zIndex: 1 }}>
        <h3 style={{ fontSize: "14px", fontWeight: 700, color: labelColor }}>Customer Price List Builder</h3>
        <p style={{ fontSize: "11px", color: helperColor, marginTop: "3px" }}>Create clean customer price lists for checks. Internal pricing is kept separate.</p>
      </div>

      {/* Customer info */}
       <div className="grid grid-cols-1 md:grid-cols-4 gap-3" style={{ position: "relative", zIndex: 1 }}>
       <div>
         <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Customer / Company Name</label>
         <input
           type="text"
           placeholder="ABC Corp"
           value={customerName}
           onChange={e => setCustomerName(e.target.value)}
           style={{ ...inputSt, "::placeholder": { color: placeholderColor } }}
         />
       </div>
       <div>
         <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Date</label>
         <input
           type="date"
           value={quoteDate}
           onChange={e => setQuoteDate(e.target.value)}
           style={selectSt}
         />
       </div>
       <div>
         <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Valid Until</label>
         <input
           type="date"
           value={validUntil}
           onChange={e => setValidUntil(e.target.value)}
           style={selectSt}
         />
       </div>
       <div>
         <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Proposal Theme</label>
         <select
           value={proposalTheme}
           onChange={e => setProposalTheme(e.target.value)}
           style={selectSt}
         >
           <option value="light">Light</option>
           <option value="dark">Dark</option>
         </select>
       </div>
      </div>

      {/* Price List Details — read-only */}
      <div style={{ position: "relative", zIndex: 1 }}>
        <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Price List Details</label>
        <div
          style={{
            height: "36px",
            borderRadius: "9px",
            padding: "0 10px",
            fontSize: "13px",
            background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)",
            border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)",
            color: isDark ? "#ffffff" : "#000000",
            display: "flex",
            alignItems: "center",
            fontWeight: 500,
          }}
        >
          {preparedByName || "Loading…"}
        </div>
      </div>

      {/* Product selection */}
      <div className="rounded-xl p-4" style={{ ...surface, position: "relative", zIndex: 1 }}>
        <p style={{ fontSize: "11px", fontWeight: 700, color: labelColor, marginBottom: "10px" }}>Add Products to Price List</p>

        <div className="space-y-3">
          {/* Product dropdown */}
          <div>
            <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Product</label>
            <div className="relative">
              <Search style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", width: "14px", height: "14px", color: helperColor, pointerEvents: "none" }} />
              <input
                type="text"
                placeholder="Search products…"
                value={selectedProduct || searchQuery}
                onChange={e => { setSearchQuery(e.target.value); setShowProductDropdown(true); setSelectedProduct(""); }}
                onFocus={() => { setShowProductDropdown(true); setSearchQuery(""); }}
                onBlur={() => setTimeout(() => setShowProductDropdown(false), 150)}
                style={{
                  ...inputSt,
                  paddingLeft: "34px",
                  color: isDark ? "#ffffff" : "#000000",
                }}
              />
            </div>
            {showProductDropdown && (
              <div className="absolute z-40 left-0 right-0 mt-1 rounded-xl overflow-y-auto -mx-2" style={{ maxHeight: "210px", minWidth: "calc(100% + 16px)", background: isDark ? "rgba(11,18,37,0.98)" : "#ffffff", border: isDark ? "1px solid rgba(255,255,255,0.15)" : "1px solid rgba(0,0,0,0.12)", boxShadow: isDark ? "0 16px 40px rgba(0,0,0,0.60)" : "0 16px 40px rgba(0,0,0,0.40)", backdropFilter: "blur(10px)" }}>
                {filteredProducts.length === 0 ? (
                  <div style={{ padding: "10px 14px", fontSize: "12px", color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)" }}>
                    No products found. Total products: {products.length}
                  </div>
                ) : (
                  filteredProducts.map(p => (
                    <button key={p.product_name} type="button" onMouseDown={() => { setSelectedProduct(p.product_name); setShowProductDropdown(false); setSearchQuery(""); }} style={{ width: "100%", textAlign: "left", padding: "10px 14px", fontSize: "12px", fontWeight: selectedProduct === p.product_name ? 600 : 400, background: selectedProduct === p.product_name ? (isDark ? "rgba(139,92,246,0.4)" : `${accentColor}25`) : "transparent", color: selectedProduct === p.product_name ? (isDark ? "#ffffff" : "#1f2937") : (isDark ? "#ffffff" : "#000000"), border: "none", cursor: "pointer", borderBottom: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.04)" }}>
                      {p.product_name}
                    </button>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Overseas selectors */}
          {isOverseas && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Country</label>
                <select
                  value={selectedCountry}
                  onChange={e => setSelectedCountry(e.target.value)}
                  style={selectSt}
                >
                  <option value="">Select country…</option>
                  {selectedCountry && <option value={selectedCountry}>{selectedCountry}</option>}
                  {countries.filter(c => c !== selectedCountry).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Check Type</label>
                <select
                  value={selectedCheckType}
                  onChange={e => setSelectedCheckType(e.target.value)}
                  style={selectSt}
                >
                  {OVERSEAS_CHECK_TYPES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Service fee & notes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Service Fee / GP (ex VAT)</label>
              <div className="relative">
                <span style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", fontSize: "13px", pointerEvents: "none", color: helperColor }}>£</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={serviceFee}
                  onChange={e => setServiceFee(e.target.value)}
                  style={{
                    ...inputSt,
                    paddingLeft: "22px",
                    color: isDark ? "#ffffff" : "#000000",
                  }}
                />
              </div>
            </div>
            <div>
              <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Customer Note (Optional)</label>
              <input
                type="text"
                placeholder="e.g. 5-day turnaround"
                value={customerNote}
                onChange={e => setCustomerNote(e.target.value)}
                style={{ ...inputSt, color: isDark ? "#ffffff" : "#000000" }}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: "10px", fontWeight: 700, color: labelColor, display: "block", marginBottom: "5px" }}>Internal Note (Staff Only)</label>
            <input
              type="text"
              placeholder="e.g. Client discount applied"
              value={internalNote}
              onChange={e => setInternalNote(e.target.value)}
              style={{ ...inputSt, color: isDark ? "#ffffff" : "#000000" }}
            />
          </div>

          <button
            type="button"
            onClick={handleAddProduct}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white"
            style={{ background: accentColor, border: "none", cursor: "pointer" }}
          >
            <Plus style={{ width: "13px", height: "13px" }} />
            Add to Price List
          </button>
        </div>
      </div>

      {/* Price list */}
      {lineItems.length > 0 && (
        <>
          {/* View toggle */}
          <div className="flex items-center gap-2" style={{ position: "relative", zIndex: 1 }}>
            <button
              type="button"
              onClick={() => setShowInternal(!showInternal)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold"
              style={{ background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)", border: isDark ? "1px solid rgba(255,255,255,0.09)" : "1px solid rgba(0,0,0,0.09)", color: dimColor, cursor: "pointer" }}
            >
              {showInternal ? <Eye style={{ width: "13px", height: "13px" }} /> : <EyeOff style={{ width: "13px", height: "13px" }} />}
              {showInternal ? "Hide Internal" : "Show Internal"}
            </button>
          </div>

          {/* Table */}
          <div className="rounded-xl overflow-hidden" style={{ ...surface, position: "relative", zIndex: 1 }}>
            <div className="overflow-x-auto">
              <table className="w-full" style={{ minWidth: "500px" }}>
                <thead>
                  <tr style={{ background: "linear-gradient(90deg, #ec2ca3, #7c3aed, #0ea5e9, #22d3ee)", color: "white" }}>
                    <th className="px-3 py-2.5 text-left" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Product</th>
                    <th className="px-3 py-2.5 text-right" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Service Fee</th>
                    <th className="px-3 py-2.5 text-right" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Price ex VAT</th>
                    <th className="px-3 py-2.5 text-right" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Total Payable</th>
                    {showInternal && (
                      <>
                        <th className="px-3 py-2.5 text-right" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Supplier Cost</th>
                        <th className="px-3 py-2.5 text-right" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Margin %</th>
                      </>
                    )}
                    <th className="px-3 py-2.5 text-center" style={{ fontSize: "10px", fontWeight: 700, color: "white" }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {lineItems.map((line, i) => (
                    <tr key={line.id} style={{ borderTop: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.05)", background: i % 2 === 0 ? "transparent" : (isDark ? "rgba(255,255,255,0.02)" : "rgba(0,0,0,0.01)") }}>
                      <td className="px-3 py-2.5" style={{ fontSize: "12px", fontWeight: 600, color: textColor }}>
                        {line.productName}
                        {line.country && <div style={{ fontSize: "10px", color: dimColor, marginTop: "2px" }}>{line.country} — {OVERSEAS_CHECK_TYPES.find(t => t.key === line.checkType)?.label}</div>}
                        {line.customerNote && <div style={{ fontSize: "10px", color: accentColor, marginTop: "2px" }}>"{line.customerNote}"</div>}
                      </td>
                      <td className="px-3 py-2.5 text-right" style={{ fontSize: "12px", color: textColor }}>{fmt(line.svcFeeEx)}</td>
                      <td className="px-3 py-2.5 text-right" style={{ fontSize: "12px", color: textColor }}>{fmt(line.customerPriceEx)}</td>
                      <td className="px-3 py-2.5 text-right" style={{ fontSize: "12px", fontWeight: 600, color: textColor }}>{fmt(line.customerPriceInc)}</td>
                      {showInternal && (
                        <>
                          <td className="px-3 py-2.5 text-right" style={{ fontSize: "11px", color: dimColor }}>{fmt(line.supplierCostInc)}</td>
                          <td className="px-3 py-2.5 text-right" style={{ fontSize: "11px", color: dimColor }}>{(line.margin * 100).toFixed(1)}%</td>
                        </>
                      )}
                      <td className="px-3 py-2.5 text-center">
                        <button type="button" onClick={() => handleRemoveLine(line.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444" }}>
                          <Trash2 style={{ width: "13px", height: "13px" }} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Price List Totals */}
          <div className="grid grid-cols-3 gap-3" style={{ position: "relative", zIndex: 1 }}>
            <div className="rounded-xl p-3" style={{ background: isDark ? `${accentColor}10` : `${accentColor}08`, border: `1px solid ${accentColor}28` }}>
              <p style={{ fontSize: "9px", fontWeight: 700, color: dimColor, marginBottom: "4px" }}>TOTAL EX VAT</p>
              <p style={{ fontSize: "18px", fontWeight: 800, color: accentColor }}>{fmt(totalCustomerEx)}</p>
            </div>
            <div className="rounded-xl p-3" style={{ background: isDark ? `${accentColor}10` : `${accentColor}08`, border: `1px solid ${accentColor}28` }}>
              <p style={{ fontSize: "9px", fontWeight: 700, color: dimColor, marginBottom: "4px" }}>TOTAL INC VAT</p>
              <p style={{ fontSize: "18px", fontWeight: 800, color: accentColor }}>{fmt(totalCustomerInc)}</p>
            </div>
            {showInternal && (
              <div className="rounded-xl p-3" style={{ background: "rgba(99,102,241,0.10)", border: "1px solid rgba(99,102,241,0.28)" }}>
                <p style={{ fontSize: "9px", fontWeight: 700, color: "#818cf8", marginBottom: "4px" }}>TOTAL MARGIN</p>
                <p style={{ fontSize: "18px", fontWeight: 800, color: "#818cf8" }}>{(totalMargin * 100).toFixed(1)}%</p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2" style={{ position: "relative", zIndex: 1 }}>
            <button
              type="button"
              onClick={copyCustomerList}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold"
              style={{ background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)", color: dimColor, cursor: "pointer" }}
            >
              {copied ? <Check style={{ width: "13px", height: "13px" }} /> : <Copy style={{ width: "13px", height: "13px" }} />}
              {copied ? "Copied!" : "Copy Customer"}
            </button>
            <button
              type="button"
              onClick={copyInternalBreakdown}
              disabled={!showInternal}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold"
              style={{ background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)", color: dimColor, cursor: "pointer", opacity: showInternal ? 1 : 0.4 }}
            >
              <Copy style={{ width: "13px", height: "13px" }} />
              Copy Internal
            </button>
            <button
              type="button"
              onClick={exportPDF}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold"
              style={{ background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)", color: dimColor, cursor: "pointer" }}
            >
              <Download style={{ width: "13px", height: "13px" }} />
              Export PDF
            </button>
            <button
              type="button"
              onClick={() => { setLineItems([]); setCustomerName(""); setQuoteDate(todayDate); setValidUntil(thirtyDaysLater); }}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold"
              style={{ background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.30)", color: "#ef4444", cursor: "pointer" }}
            >
              Reset
            </button>
          </div>
        </>
      )}

      {lineItems.length === 0 && (
      <div className="rounded-xl py-12 text-center" style={{ ...surface, position: "relative", zIndex: 1 }}>
      <p style={{ fontSize: "13px", fontWeight: 600, color: textColor }}>No products added yet</p>
      <p style={{ fontSize: "11px", color: helperColor, marginTop: "4px" }}>Select products above to build a customer price list</p>
      </div>
      )}
    </div>
  );
}