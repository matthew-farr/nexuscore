import { useState, useMemo, useEffect } from "react";
import { RotateCcw, Copy, Check, AlertTriangle, ChevronDown, Info, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { PRODUCTS as FALLBACK_PRODUCTS, OVERSEAS_PRICING as FALLBACK_OVERSEAS, OVERSEAS_CHECK_TYPES } from "../../../lib/pricingData";

// ── helpers ───────────────────────────────────────────────────
const fmt    = (n) => `£${(isFinite(n) ? n : 0).toFixed(2)}`;
const fmtPct = (n) => `${(isFinite(n) ? n * 100 : 0).toFixed(1)}%`;
const parseCost = (s) => { if (s === "" || s == null) return null; const n = parseFloat(s); return isFinite(n) ? n : null; };

const SERVICE_FEE_VAT = 0.20;
const VAT_OPTS = [
  { label: "0%",     value: 0 },
  { label: "5%",     value: 0.05 },
  { label: "20%",    value: 0.20 },
  { label: "Custom", value: "custom" },
];

// CERTN flag key per check type
const CERTN_FLAG = {
  financial_integrity: "is_certn_fi",
  criminal_history:    "is_certn_ch",
  directorship:        "is_certn_dir",
};

// Returns: number (cost) | "CERTN" | null (not available)
const overseasCostFromEntity = (record, checkTypeKey) => {
  if (!record) return null;
  // Check CERTN flag first
  const certnFlag = CERTN_FLAG[checkTypeKey];
  if (certnFlag && record[certnFlag]) return "CERTN";
  const val = record[`${checkTypeKey}_cost`];
  if (val == null || val === "") return null;
  const n = parseFloat(val);
  if (!isFinite(n) || n <= 0) return null;  // 0 or NaN = not available
  return n;
};

// Convert Base44 PricingProduct → internal product shape
const entityToProduct = (r) => ({
  id:              r.id,
  name:            r.product_name,
  costEx:          r.supplier_cost_ex_vat ?? 0,
  vatRate:         r.supplier_vat_rate ?? 0,
  defaultGP:       r.default_service_fee_ex_vat ?? 0,
  serviceFeeVat:   r.service_fee_vat_rate ?? SERVICE_FEE_VAT,
  isOverseas:      r.product_type === "Overseas",
  lastUpdated:     r.last_updated,
});

// Convert hardcoded fallback to same shape
const fallbackToProduct = (f) => ({
  id: null, name: f.name, costEx: f.costEx, vatRate: f.vatRate,
  defaultGP: 0, serviceFeeVat: SERVICE_FEE_VAT, isOverseas: !!f.isOverseas, lastUpdated: null,
});

// ── component ──────────────────────────────────────────────────
export default function PricingCalculator({ isDark, accentColor }) {
  // Pricing data state
  const [dbProducts,  setDbProducts]  = useState(null); // null = loading
  const [dbOverseas,  setDbOverseas]  = useState(null);
  const [loadError,   setLoadError]   = useState(false);

  // Calculator inputs
  const [productName,    setProductName]    = useState("");
  const [country,        setCountry]        = useState("");
  const [checkType,      setCheckType]      = useState("criminal_history");
  const [supplierCostEx, setSupplierCostEx] = useState("");
  const [vatRateKey,     setVatRateKey]     = useState(0.20);
  const [customVatRate,  setCustomVatRate]  = useState("");
  const [serviceFee,     setServiceFee]     = useState("");
  const [copied,         setCopied]         = useState(false);
  const [searchQuery,    setSearchQuery]    = useState("");
  const [showDropdown,   setShowDropdown]   = useState(false);

  // Load admin pricing from Base44
  useEffect(() => {
    Promise.all([
      base44.entities.PricingProduct.filter({ is_active: true }, "display_order", 500),
      base44.entities.OverseasPricingRate.filter({ is_active: true }, "country", 500),
    ]).then(([prods, overs]) => {
      setDbProducts(prods);
      setDbOverseas(overs);
    }).catch(() => {
      setLoadError(true);
      setDbProducts([]);
      setDbOverseas([]);
    });
  }, []);

  const loading = dbProducts === null;

  // Resolve product list — prefer DB, fallback only if DB is completely empty
  const usingFallback = !loading && dbProducts.length === 0;
  const usingOverseasFallback = !loading && (dbOverseas || []).length === 0;

  const products = useMemo(() => {
    if (loading) return [];
    if (usingFallback) return FALLBACK_PRODUCTS.map(fallbackToProduct);
    // DB already filtered to is_active:true, deduplicate by name and sort
    const byName = {};
    for (const p of dbProducts) {
      const norm = String(p.product_name || "").toLowerCase().trim();
      if (!byName[norm] || new Date(p.last_updated || p.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
        byName[norm] = p;
      }
    }
    return Object.values(byName).map(entityToProduct).sort((a, b) => a.name.localeCompare(b.name));
  }, [loading, usingFallback, dbProducts]);

  // Overseas country list — from DB if available, else fallback, deduplicate for display
  const countries = useMemo(() => {
    if (usingOverseasFallback) return FALLBACK_OVERSEAS.map(r => r.country).sort();
    const byName = {};
    for (const o of (dbOverseas || [])) {
      const norm = String(o.country || "").toLowerCase().trim();
      if (!byName[norm] || new Date(o.last_updated || o.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
        byName[norm] = o;
      }
    }
    return Object.keys(byName).sort();
  }, [usingOverseasFallback, dbOverseas]);

  // Latest pricing update date
  const lastUpdated = useMemo(() => {
    if (usingFallback || !dbProducts?.length) return null;
    const dates = dbProducts.map(p => p.last_updated).filter(Boolean).sort();
    return dates[dates.length - 1];
  }, [usingFallback, dbProducts]);

  // Filtered dropdown list — always show all products, but pin selected at top
  const filteredProducts = useMemo(() => {
    if (!searchQuery) {
      // No search: show selected first, then rest
      const selected = products.find(p => p.name === productName);
      const rest = products.filter(p => p.name !== productName);
      return selected ? [selected, ...rest] : products;
    }
    // With search: filter by query
    return products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [products, searchQuery, productName]);

  // Selected product
  const product    = products.find(p => p.name === productName);
  const isOverseas = !!product?.isOverseas;

  // Resolve supplier VAT rate
  const supplierVatRate = vatRateKey === "custom"
    ? (parseFloat(customVatRate) / 100 || 0)
    : (vatRateKey ?? 0);

  // Parse supplier cost field
  const costEx = parseCost(supplierCostEx);

  // Overseas availability — match by normalised country name
  const overseasLookupDone = isOverseas && country !== "" && checkType !== "";
  const overseasCostResult = useMemo(() => {
    if (!overseasLookupDone) return undefined;
    if (usingOverseasFallback) {
      const row = FALLBACK_OVERSEAS.find(r => String(r.country || "").toLowerCase().trim() === String(country || "").toLowerCase().trim());
      if (!row) return null;
      const val = row[checkType];
      return (val && val > 0) ? val : null;
    }
    const normCountry = String(country || "").toLowerCase().trim();
    const byName = {};
    for (const o of (dbOverseas || [])) {
      const norm = String(o.country || "").toLowerCase().trim();
      if (norm === normCountry) {
        if (!byName[norm] || new Date(o.last_updated || o.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
          byName[norm] = o;
        }
      }
    }
    const record = byName[normCountry];
    return overseasCostFromEntity(record, checkType);
  }, [overseasLookupDone, country, checkType, usingOverseasFallback, dbOverseas]);

  const overseasIsCertn     = overseasLookupDone && overseasCostResult === "CERTN";
  const overseasUnavailable = overseasLookupDone && (overseasCostResult === null || overseasIsCertn);

  // ── Calculations ─────────────────────────────────────────────
  const calc = useMemo(() => {
    if (costEx === null) return null;
    if (overseasUnavailable) return null;
    const cost    = costEx;
    const gp      = parseFloat(serviceFee) || 0;
    const sfVat   = product?.serviceFeeVat ?? SERVICE_FEE_VAT;
    const costInc = cost * (1 + supplierVatRate);
    const custExVat   = cost + gp;
    const custIncVat  = costInc + gp * (1 + sfVat);
    const totalVat    = custIncVat - custExVat;
    const supplierVat = costInc - cost;
    const serviceVat  = gp * sfVat;
    const margin      = custExVat > 0 ? gp / custExVat : 0;
    return { cost, costInc, gp, custExVat, custIncVat, totalVat, supplierVat, serviceVat, margin };
  }, [costEx, supplierVatRate, serviceFee, overseasUnavailable, product]);

  // ── Handlers ──────────────────────────────────────────────────
  const selectProduct = (p) => {
    setProductName(p.name);
    setSearchQuery(p.name);
    setShowDropdown(false);
    setCountry(""); setCheckType("criminal_history");
    if (!p.isOverseas) {
      setSupplierCostEx(p.costEx.toFixed(2));
      setVatRateKey(p.vatRate);
      setServiceFee(p.defaultGP > 0 ? p.defaultGP.toFixed(2) : "");
    } else {
      setSupplierCostEx(""); setVatRateKey(0.20); setServiceFee("");
    }
  };

  const lookupOverseasCost = (c, ct) => {
    if (usingOverseasFallback) {
      const row = FALLBACK_OVERSEAS.find(r => String(r.country || "").toLowerCase().trim() === String(c || "").toLowerCase().trim());
      if (!row) return null;
      const val = row[ct];
      return (val && val > 0) ? val : null;
    }
    const normCountry = String(c || "").toLowerCase().trim();
    const byName = {};
    for (const o of (dbOverseas || [])) {
      const norm = String(o.country || "").toLowerCase().trim();
      if (norm === normCountry) {
        if (!byName[norm] || new Date(o.last_updated || o.created_date) > new Date(byName[norm].last_updated || byName[norm].created_date)) {
          byName[norm] = o;
        }
      }
    }
    const record = byName[normCountry];
    return overseasCostFromEntity(record, ct);
  };

  const handleCountryChange = (newCountry) => {
    setCountry(newCountry);
    if (!newCountry) { setSupplierCostEx(""); return; }
    const cost = lookupOverseasCost(newCountry, checkType);
    // CERTN or null = clear cost field
    setSupplierCostEx(typeof cost === "number" ? cost.toFixed(2) : "");
  };

  const handleCheckTypeChange = (newType) => {
    setCheckType(newType);
    if (!country) return;
    const cost = lookupOverseasCost(country, newType);
    setSupplierCostEx(typeof cost === "number" ? cost.toFixed(2) : "");
  };

  const reset = () => {
    setProductName(""); setSearchQuery(""); setCountry(""); setCheckType("criminal_history");
    setSupplierCostEx(""); setVatRateKey(0.20); setCustomVatRate(""); setServiceFee("");
  };

  const copySummary = () => {
    if (!calc) return;
    const checkLabel = OVERSEAS_CHECK_TYPES.find(t => t.key === checkType)?.label ?? checkType;
    const lines = [
      "Checks Direct — Pricing Summary",
      "─".repeat(40),
      `Product:                ${productName || "—"}`,
      ...(isOverseas && country   ? [`Country:                ${country}`]       : []),
      ...(isOverseas && checkType ? [`Check Type:             ${checkLabel}`]    : []),
      "─".repeat(40),
      `Supplier Cost ex VAT:   ${fmt(calc.cost)}`,
      `Supplier VAT:           ${fmt(calc.supplierVat)}`,
      `Supplier Cost inc VAT:  ${fmt(calc.costInc)}`,
      "─".repeat(40),
      `Service Fee / GP:       ${fmt(calc.gp)}`,
      `VAT on Service Fee:     ${fmt(calc.serviceVat)}`,
      "─".repeat(40),
      `Customer Price ex VAT:  ${fmt(calc.custExVat)}`,
      `Customer Price inc VAT: ${fmt(calc.custIncVat)}`,
      `Total VAT:              ${fmt(calc.totalVat)}`,
      `Margin:                 ${fmtPct(calc.margin)}`,
    ].join("\n");
    navigator.clipboard.writeText(lines);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  // ── Shared styles ─────────────────────────────────────────────
  const surface  = { background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.03)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.07)", borderRadius: "12px" };
  const inputSt  = { width: "100%", height: "36px", borderRadius: "9px", padding: "0 10px", fontSize: "13px", background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)", border: isDark ? "1px solid rgba(255,255,255,0.09)" : "1px solid rgba(0,0,0,0.09)", color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 12%)", outline: "none", accentColor: isDark ? "rgba(255,255,255,0.5)" : "auto" };
  const selectSt = { ...inputSt, colorScheme: isDark ? "dark" : "light" };
  const lbl      = { fontSize: "10px", fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase", color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)", display: "block", marginBottom: "5px" };
  const dimTxt   = { fontSize: "12px", color: isDark ? "rgba(255,255,255,0.48)" : "rgba(0,0,0,0.45)" };
  const valTxt   = { fontSize: "13px", fontWeight: 600, color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 12%)" };
  const vatBtnSt = (opt) => ({
    flex: 1, height: "32px", borderRadius: "8px", fontSize: "11px", fontWeight: 600, cursor: "pointer",
    background: vatRateKey === opt.value ? `${accentColor}22` : (isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)"),
    border: `1px solid ${vatRateKey === opt.value ? accentColor + "55" : (isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)")}`,
    color: vatRateKey === opt.value ? accentColor : (isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)"),
  });

  // ── Loading state ─────────────────────────────────────────────
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <Loader2 style={{ width: "24px", height: "24px", color: accentColor, animation: "spin 1s linear infinite" }} />
        <p style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)" }}>Loading pricing data…</p>
        <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div className="space-y-5">

      {/* Fallback / error banner */}
      {usingFallback && (
        <div className="flex items-start gap-2 rounded-xl px-3 py-2.5" style={{ background: "rgba(245,158,11,0.10)", border: "1px solid rgba(245,158,11,0.25)" }}>
          <AlertTriangle style={{ width: "13px", height: "13px", color: "#f59e0b", flexShrink: 0, marginTop: "1px" }} />
          <p style={{ fontSize: "11px", color: isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.58)", lineHeight: 1.5 }}>
            <strong style={{ color: "#f59e0b" }}>Using fallback pricing data.</strong> Admin pricing has not been uploaded yet. Go to Admin Hub → Pricing to upload your pricing CSV.
          </p>
        </div>
      )}

      {/* Admin-controlled note */}
      <div className="flex items-start gap-2 rounded-xl px-3 py-2.5" style={{ background: `${accentColor}0e`, border: `1px solid ${accentColor}22` }}>
        <Info style={{ width: "13px", height: "13px", color: accentColor, flexShrink: 0, marginTop: "1px" }} />
        <p style={{ fontSize: "11px", color: isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.55)", lineHeight: 1.5 }}>
          Master pricing is <strong style={{ color: isDark ? "rgba(255,255,255,0.75)" : "rgba(0,0,0,0.70)" }}>admin-controlled</strong> via Admin Hub → Pricing. Some supplier costs are VAT-exempt (e.g. DBS fees). The Checks Direct service fee attracts 20% VAT. <strong style={{ color: isDark ? "rgba(255,255,255,0.75)" : "rgba(0,0,0,0.70)" }}>Overrides here do not update master pricing.</strong>
        </p>
      </div>

      {/* ── INPUTS ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {/* Searchable product dropdown */}
        <div className="md:col-span-2 relative">
          <label style={lbl}>Product</label>
          <div className="relative">
            <input
              type="text"
              placeholder="Type to search products…"
              value={searchQuery}
              onChange={e => { setSearchQuery(e.target.value); setShowDropdown(true); if (!e.target.value) { setProductName(""); setSupplierCostEx(""); } }}
              onFocus={() => { setShowDropdown(true); setSearchQuery(""); }}
              onBlur={() => setTimeout(() => setShowDropdown(false), 180)}
              style={{ ...inputSt, paddingRight: "34px" }}
            />
            <ChevronDown style={{ position: "absolute", right: "10px", top: "50%", transform: "translateY(-50%)", width: "14px", height: "14px", color: isDark ? "rgba(255,255,255,0.28)" : "rgba(0,0,0,0.28)", pointerEvents: "none" }} />
          </div>

          {showDropdown && filteredProducts.length > 0 && (
            <div className="absolute z-40 left-0 right-0 mt-1 rounded-xl overflow-y-auto" style={{ maxHeight: "210px", background: isDark ? "rgba(11,18,37,0.98)" : "#ffffff", border: isDark ? "1px solid rgba(255,255,255,0.15)" : "1px solid rgba(0,0,0,0.12)", boxShadow: isDark ? "0 16px 40px rgba(0,0,0,0.60), 0 0 20px rgba(139,92,246,0.08)" : "0 16px 40px rgba(0,0,0,0.40)", backdropFilter: "blur(10px)" }}>
              {filteredProducts.map(p => (
                <button key={p.name} type="button" onMouseDown={() => selectProduct(p)} className="w-full text-left px-3 py-2 flex items-center justify-between transition-colors"
                  style={{ background: productName === p.name ? (isDark ? `${accentColor}25` : `${accentColor}18`) : (isDark ? "transparent" : "transparent"), color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 15%)", fontSize: "12px", fontWeight: productName === p.name ? 600 : 400, cursor: "pointer", borderBottom: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.04)" }}
                  onMouseEnter={(e) => { if (productName !== p.name) e.currentTarget.style.background = isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.03)"; }}
                  onMouseLeave={(e) => { if (productName !== p.name) e.currentTarget.style.background = "transparent"; }}>
                  <span>{p.name}</span>
                  <span style={{ fontSize: "10px", color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.30)", flexShrink: 0, marginLeft: "8px" }}>
                    {p.isOverseas ? "🌐 Overseas" : p.vatRate === 0 ? "VAT exempt" : `${p.vatRate * 100}% VAT`}
                  </span>
                </button>
              ))}
            </div>
          )}

          {showDropdown && searchQuery && filteredProducts.length === 0 && (
            <div className="absolute z-40 left-0 right-0 mt-1 rounded-xl px-4 py-3" style={{ background: isDark ? "rgba(11,18,37,0.98)" : "#ffffff", border: isDark ? "1px solid rgba(255,255,255,0.15)" : "1px solid rgba(0,0,0,0.10)", boxShadow: isDark ? "0 8px 24px rgba(0,0,0,0.60)" : "0 8px 24px rgba(0,0,0,0.25)", backdropFilter: "blur(10px)" }}>
              <p style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.35)" }}>No products match "{searchQuery}"</p>
            </div>
          )}
        </div>

        {/* Overseas selectors */}
        {isOverseas && (
          <>
            <div>
              <label style={lbl}>Country</label>
              <select value={country} onChange={e => handleCountryChange(e.target.value)} style={selectSt}>
                <option value="">Select country…</option>
                {country && <option key={country} value={country}>{country}</option>}
                {countries.filter(c => c !== country).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl}>Check Type</label>
              <select value={checkType} onChange={e => handleCheckTypeChange(e.target.value)} style={selectSt}>
                {OVERSEAS_CHECK_TYPES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
              </select>
            </div>
          </>
        )}

        {/* Supplier Cost ex VAT */}
        <div>
          <label style={lbl}>Supplier Cost ex VAT</label>
          {overseasIsCertn ? (
            <div className="flex items-center gap-2 rounded-xl px-3" style={{ height: "36px", background: "rgba(99,102,241,0.10)", border: "1px solid rgba(99,102,241,0.30)" }}>
              <span style={{ fontSize: "12px", color: "#818cf8", fontWeight: 600 }}>Handled via CERTN</span>
            </div>
          ) : overseasUnavailable ? (
            <div className="flex items-center gap-2 rounded-xl px-3" style={{ height: "36px", background: "rgba(239,68,68,0.09)", border: "1px solid rgba(239,68,68,0.28)" }}>
              <AlertTriangle style={{ width: "12px", height: "12px", color: "#ef4444", flexShrink: 0 }} />
              <span style={{ fontSize: "12px", color: "#ef4444", fontWeight: 600 }}>Not available</span>
            </div>
          ) : (
            <div className="relative">
              <span style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", fontSize: "13px", pointerEvents: "none", color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)" }}>£</span>
              <input type="number" min="0" step="0.01" placeholder="0.00" value={supplierCostEx} readOnly style={{ ...inputSt, paddingLeft: "22px", cursor: "not-allowed", opacity: 0.7 }} />
            </div>
          )}
        </div>

        {/* Supplier VAT Rate */}
        <div>
          <label style={lbl}>Supplier VAT Rate</label>
          <div className="flex gap-1.5">
            {VAT_OPTS.map(opt => (
              <button type="button" key={String(opt.value)} onClick={() => setVatRateKey(opt.value)} style={vatBtnSt(opt)}>{opt.label}</button>
            ))}
          </div>
          {vatRateKey === "custom" && (
            <input type="number" min="0" max="100" placeholder="Enter %" value={customVatRate} onChange={e => setCustomVatRate(e.target.value)} style={{ ...inputSt, marginTop: "6px" }} />
          )}
        </div>

        {/* Supplier Cost inc VAT — computed */}
        <div>
          <label style={lbl}>Supplier Cost inc VAT</label>
          <div className="flex items-center px-3 rounded-xl" style={{ height: "36px", fontSize: "13px", fontWeight: costEx !== null ? 600 : 400, background: isDark ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.02)", border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.05)", color: costEx !== null ? (isDark ? "rgba(255,255,255,0.70)" : "hsl(230 25% 20%)") : (isDark ? "rgba(255,255,255,0.22)" : "rgba(0,0,0,0.22)") }}>
            {costEx !== null && !overseasUnavailable ? fmt(costEx * (1 + supplierVatRate)) : "—"}
          </div>
        </div>

        {/* Service Fee */}
        <div>
          <label style={lbl}>GP / Service Fee ex VAT</label>
          <div className="relative">
            <span style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", fontSize: "13px", pointerEvents: "none", color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)" }}>£</span>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={serviceFee} onChange={e => setServiceFee(e.target.value)} style={{ ...inputSt, paddingLeft: "22px" }} />
          </div>
          <p style={{ fontSize: "10px", marginTop: "4px", color: isDark ? "rgba(255,255,255,0.28)" : "rgba(0,0,0,0.30)" }}>
            VAT at {product?.serviceFeeVat != null ? `${(product.serviceFeeVat * 100).toFixed(0)}%` : "20%"} · Override does not update master pricing
          </p>
        </div>
      </div>

      {/* ── STATES ── */}
      {!productName && (
        <div className="rounded-xl px-4 py-8 text-center" style={surface}>
          <p style={{ fontSize: "13px", fontWeight: 600, color: isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.28)", marginBottom: "4px" }}>Select a product to begin</p>
          <p style={{ fontSize: "11px", color: isDark ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.20)" }}>Search the dropdown — {products.length} products available.</p>
        </div>
      )}

      {isOverseas && country && overseasIsCertn && (
        <div className="rounded-xl px-4 py-3 flex items-center gap-2.5" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.22)", borderRadius: "12px" }}>
          <span style={{ fontSize: "14px" }}>🔗</span>
          <p style={{ fontSize: "12px", color: isDark ? "#a5b4fc" : "#4f46e5" }}>
            <strong>{country}</strong> — {OVERSEAS_CHECK_TYPES.find(t => t.key === checkType)?.label} is handled via CERTN. Contact your team lead for a quote.
          </p>
        </div>
      )}
      {isOverseas && country && !overseasIsCertn && overseasUnavailable && (
        <div className="rounded-xl px-4 py-3 flex items-center gap-2.5" style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.22)", borderRadius: "12px" }}>
          <AlertTriangle style={{ width: "14px", height: "14px", color: "#ef4444", flexShrink: 0 }} />
          <p style={{ fontSize: "12px", color: "#f87171" }}>
            Not available for <strong>{country}</strong> — {OVERSEAS_CHECK_TYPES.find(t => t.key === checkType)?.label}. Contact your team lead.
          </p>
        </div>
      )}

      {productName && !isOverseas && costEx === null && (
        <div className="rounded-xl px-4 py-3 flex items-center gap-2.5" style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.22)", borderRadius: "12px" }}>
          <Info style={{ width: "14px", height: "14px", color: "#f59e0b", flexShrink: 0 }} />
          <p style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.55)" }}>Enter a supplier cost to calculate pricing. You can override the auto-filled value.</p>
        </div>
      )}

      {/* ── RESULTS ── */}
      {calc && (
        <>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Customer Price\nex VAT",  value: fmt(calc.custExVat),  color: accentColor },
              { label: "Customer Price\ninc VAT",  value: fmt(calc.custIncVat), color: "#ec4899" },
              { label: "Gross Profit",             value: fmt(calc.gp),         color: "#10b981" },
            ].map(({ label, value, color }) => (
              <div key={label} className="rounded-xl p-3 flex flex-col gap-1" style={{ background: isDark ? `${color}10` : `${color}08`, border: `1px solid ${color}28` }}>
                <span style={{ fontSize: "9px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: isDark ? `${color}cc` : color, whiteSpace: "pre-line", lineHeight: 1.3 }}>{label}</span>
                <span style={{ fontSize: "clamp(16px, 2.5vw, 22px)", fontWeight: 800, color, lineHeight: 1.1 }}>{value}</span>
              </div>
            ))}
          </div>

          <div className="rounded-xl p-4" style={surface}>
            <p style={{ fontSize: "10px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: isDark ? "rgba(255,255,255,0.28)" : "rgba(0,0,0,0.28)", marginBottom: "10px" }}>Full Breakdown</p>
            <div>
              {[
                { label: "Supplier Cost ex VAT",    value: fmt(calc.cost),        sub: false },
                { label: "Supplier VAT",             value: fmt(calc.supplierVat), sub: true  },
                { label: "Supplier Cost inc VAT",    value: fmt(calc.costInc),     sub: false },
                null,
                { label: "Service Fee / GP",         value: fmt(calc.gp),          sub: false },
                { label: `VAT on Service Fee (${product?.serviceFeeVat != null ? (product.serviceFeeVat * 100).toFixed(0) : "20"}%)`, value: fmt(calc.serviceVat), sub: true },
                null,
                { label: "Customer Price ex VAT",    value: fmt(calc.custExVat),   sub: false },
                { label: "Customer Price inc VAT",   value: fmt(calc.custIncVat),  sub: false },
                { label: "Total VAT Amount",         value: fmt(calc.totalVat),    sub: false },
                { label: "Margin %",                 value: fmtPct(calc.margin),   sub: false },
              ].map((row, i) =>
                row === null ? (
                  <div key={i} style={{ height: "1px", background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)", margin: "6px 0" }} />
                ) : (
                  <div key={row.label} className="flex justify-between py-1.5">
                    <span style={{ ...dimTxt, paddingLeft: row.sub ? "10px" : "0", opacity: row.sub ? 0.7 : 1 }}>{row.label}</span>
                    <span style={valTxt}>{row.value}</span>
                  </div>
                )
              )}
            </div>
          </div>
        </>
      )}

      {/* ── ACTIONS ── */}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={reset} className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold"
          style={{ background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)", border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)", color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)", cursor: "pointer" }}>
          <RotateCcw style={{ width: "12px", height: "12px" }} />
          Reset
        </button>
        <button type="button" onClick={copySummary} disabled={!calc} className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold"
          style={{ background: copied ? "rgba(16,185,129,0.18)" : `${accentColor}18`, border: `1px solid ${copied ? "#10b981" : accentColor}45`, color: copied ? "#10b981" : accentColor, cursor: calc ? "pointer" : "not-allowed", opacity: calc ? 1 : 0.4 }}>
          {copied ? <Check style={{ width: "12px", height: "12px" }} /> : <Copy style={{ width: "12px", height: "12px" }} />}
          {copied ? "Copied!" : "Copy Summary"}
        </button>
      </div>

      {/* Footer */}
      <p style={{ fontSize: "10px", textAlign: "center", color: isDark ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.22)" }}>
        {usingFallback
          ? "⚠ Using fallback data — upload admin pricing to activate live rates"
          : lastUpdated
            ? `Pricing last updated ${new Date(lastUpdated).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })} · Confirm with finance before quoting`
            : "Prices are indicative — confirm with finance before quoting"}
      </p>
    </div>
  );
}