import { useState } from "react";
import { Plus, Trash2, Copy, RotateCcw, Check } from "lucide-react";

const VAT_RATES = ["20", "5", "0", "custom"];

const emptyLine = () => ({
  id: Date.now() + Math.random(),
  desc: "",
  net: "",
  rateKey: "20",
  customRate: "",
  vatable: true,
});

export default function VatCalculator({ isDark, accentColor }) {
  const [lines, setLines] = useState([emptyLine()]);
  const [note, setNote] = useState("");
  const [copied, setCopied] = useState(false);

  const updateLine = (id, field, val) =>
    setLines(prev => prev.map(l => (l.id === id ? { ...l, [field]: val } : l)));

  const addLine = () => setLines(prev => [...prev, emptyLine()]);
  const removeLine = (id) => setLines(prev => prev.filter(l => l.id !== id));
  const reset = () => { setLines([emptyLine()]); setNote(""); };

  const getRate = (l) => {
    if (!l.vatable) return 0;
    if (l.rateKey === "custom") return parseFloat(l.customRate) / 100 || 0;
    return parseFloat(l.rateKey) / 100;
  };

  const calcLine = (l) => {
    const net = parseFloat(l.net) || 0;
    const rate = getRate(l);
    const vat = net * rate;
    return { net, vat, gross: net + vat };
  };

  const totals = lines.reduce(
    (acc, l) => {
      const { net, vat, gross } = calcLine(l);
      return { net: acc.net + net, vat: acc.vat + vat, gross: acc.gross + gross };
    },
    { net: 0, vat: 0, gross: 0 }
  );

  const copySummary = () => {
    const rows = lines.map((l, i) => {
      const { net, vat, gross } = calcLine(l);
      const desc = l.desc || `Line ${i + 1}`;
      const rateLabel = l.vatable ? (l.rateKey === "custom" ? `${l.customRate}%` : `${l.rateKey}%`) : "Non-VATable";
      return `${desc}: Net £${net.toFixed(2)}, VAT £${vat.toFixed(2)} (${rateLabel}), Gross £${gross.toFixed(2)}`;
    });
    const summary = [
      "=== VAT Breakdown ===",
      ...rows,
      "---",
      `Total Net: £${totals.net.toFixed(2)}`,
      `Total VAT: £${totals.vat.toFixed(2)}`,
      `Total Gross: £${totals.gross.toFixed(2)}`,
      note ? `\nNote: ${note}` : "",
    ].filter(Boolean).join("\n");
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Styles
  const surface = {
    background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.03)",
    border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.07)",
  };
  const inputBase = {
    background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)",
    border: isDark ? "1px solid rgba(255,255,255,0.09)" : "1px solid rgba(0,0,0,0.09)",
    color: isDark ? "rgba(255,255,255,0.85)" : "hsl(230 25% 15%)",
    borderRadius: "8px",
    padding: "0 8px",
    fontSize: "12px",
    height: "32px",
    outline: "none",
    width: "100%",
  };
  const labelSm = {
    fontSize: "10px",
    fontWeight: 600,
    color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)",
    marginBottom: "3px",
    display: "block",
  };
  const dimText = { color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)", fontSize: "12px" };
  const boldText = { color: isDark ? "rgba(255,255,255,0.90)" : "hsl(230 25% 12%)", fontWeight: 600, fontSize: "12px" };

  return (
    <div className="space-y-4">

      {/* Line items */}
      <div className="space-y-3">
        {lines.map((l, idx) => {
          const { net, vat, gross } = calcLine(l);
          const showCustom = l.vatable && l.rateKey === "custom";
          return (
            <div
              key={l.id}
              className="rounded-xl p-3 relative"
              style={{
                ...surface,
                borderLeft: `3px solid ${l.vatable ? accentColor + "70" : "rgba(148,163,184,0.35)"}`,
              }}
            >
              {/* Row header */}
              <div className="flex items-center justify-between mb-2.5">
                <span style={{ fontSize: "11px", fontWeight: 700, color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.35)" }}>
                  Line {idx + 1}
                </span>
                <div className="flex items-center gap-2">
                  {/* VATable toggle */}
                  <div className="flex rounded-lg overflow-hidden" style={{ border: isDark ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.10)" }}>
                    {[true, false].map((v) => (
                      <button
                        key={String(v)}
                        onClick={() => updateLine(l.id, "vatable", v)}
                        style={{
                          fontSize: "10px",
                          fontWeight: 600,
                          padding: "3px 8px",
                          cursor: "pointer",
                          border: "none",
                          background: l.vatable === v
                            ? (v ? `${accentColor}25` : "rgba(148,163,184,0.18)")
                            : "transparent",
                          color: l.vatable === v
                            ? (v ? accentColor : (isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.55)"))
                            : (isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.30)"),
                          transition: "all 0.15s",
                        }}
                      >
                        {v ? "VATable" : "Non-VATable"}
                      </button>
                    ))}
                  </div>
                  {/* Remove */}
                  {lines.length > 1 && (
                    <button
                      onClick={() => removeLine(l.id)}
                      style={{ width: "26px", height: "26px", borderRadius: "7px", background: "rgba(239,68,68,0.10)", border: "1px solid rgba(239,68,68,0.20)", color: "#ef4444", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}
                    >
                      <Trash2 style={{ width: "11px", height: "11px" }} />
                    </button>
                  )}
                </div>
              </div>

              {/* Fields — desktop grid, mobile stacked */}
              <div className="grid gap-2" style={{ gridTemplateColumns: "2fr 90px 90px 90px" }}>
                {/* Description */}
                <div>
                  <label style={labelSm}>Description</label>
                  <input
                    placeholder="e.g. Enhanced DBS, Service Fee…"
                    value={l.desc}
                    onChange={e => updateLine(l.id, "desc", e.target.value)}
                    style={inputBase}
                  />
                </div>

                {/* Net Amount */}
                <div>
                  <label style={labelSm}>Net (£)</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    value={l.net}
                    onChange={e => updateLine(l.id, "net", e.target.value)}
                    style={inputBase}
                  />
                </div>

                {/* VAT Rate */}
                <div>
                  <label style={labelSm}>VAT Rate</label>
                  <select
                    value={l.rateKey}
                    onChange={e => updateLine(l.id, "rateKey", e.target.value)}
                    disabled={!l.vatable}
                    style={{ ...inputBase, opacity: l.vatable ? 1 : 0.4 }}
                  >
                    <option value="20">20%</option>
                    <option value="5">5%</option>
                    <option value="0">0%</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>

                {/* Custom rate or Gross output */}
                <div>
                  {showCustom ? (
                    <>
                      <label style={labelSm}>Custom %</label>
                      <input
                        type="number"
                        placeholder="%"
                        value={l.customRate}
                        onChange={e => updateLine(l.id, "customRate", e.target.value)}
                        style={inputBase}
                      />
                    </>
                  ) : (
                    <>
                      <label style={labelSm}>Gross (£)</label>
                      <div
                        style={{ ...inputBase, display: "flex", alignItems: "center", background: isDark ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.02)", fontWeight: 700, color: accentColor }}
                      >
                        {gross.toFixed(2)}
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Row totals */}
              <div className="flex flex-wrap gap-3 mt-2.5 pt-2" style={{ borderTop: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.05)" }}>
                <span style={dimText}>VAT: <span style={{ color: l.vatable ? accentColor : (isDark ? "rgba(255,255,255,0.38)" : "rgba(0,0,0,0.35)"), fontWeight: 600 }}>£{vat.toFixed(2)}</span></span>
                <span style={dimText}>Net: <span style={boldText}>£{net.toFixed(2)}</span></span>
                {showCustom && <span style={dimText}>Gross: <span style={{ ...boldText, color: accentColor }}>£{gross.toFixed(2)}</span></span>}
                {!l.vatable && <span style={{ fontSize: "10px", fontWeight: 600, color: "#94a3b8", background: "rgba(148,163,184,0.12)", border: "1px solid rgba(148,163,184,0.20)", borderRadius: "6px", padding: "1px 6px" }}>VAT Exempt</span>}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add line */}
      <button
        onClick={addLine}
        className="flex items-center gap-1.5 w-full justify-center rounded-xl py-2 transition-all duration-150"
        style={{
          background: `${accentColor}10`,
          border: `1px dashed ${accentColor}35`,
          color: accentColor,
          fontSize: "12px",
          fontWeight: 600,
          cursor: "pointer",
        }}
        onMouseEnter={e => { e.currentTarget.style.background = `${accentColor}18`; e.currentTarget.style.borderColor = `${accentColor}60`; }}
        onMouseLeave={e => { e.currentTarget.style.background = `${accentColor}10`; e.currentTarget.style.borderColor = `${accentColor}35`; }}
      >
        <Plus style={{ width: "13px", height: "13px" }} />
        Add Line
      </button>

      {/* Totals */}
      <div className="rounded-xl p-4" style={surface}>
        <div className="flex items-center justify-between mb-3">
          <span style={{ fontSize: "11px", fontWeight: 700, color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.35)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
            Summary · {lines.length} line{lines.length !== 1 ? "s" : ""}
          </span>
        </div>
        <div className="space-y-1.5">
          {[
            { label: "Total Net", value: `£${totals.net.toFixed(2)}` },
            { label: "Total VAT", value: `£${totals.vat.toFixed(2)}` },
          ].map(({ label, value }) => (
            <div key={label} className="flex justify-between pb-1.5" style={{ borderBottom: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.05)" }}>
              <span style={dimText}>{label}</span>
              <span style={boldText}>{value}</span>
            </div>
          ))}
          <div className="flex justify-between pt-0.5">
            <span style={{ fontSize: "13px", fontWeight: 700, color: isDark ? "rgba(255,255,255,0.85)" : "hsl(230 25% 12%)" }}>Total Gross</span>
            <span style={{ fontSize: "18px", fontWeight: 800, color: accentColor }}>£{totals.gross.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Note */}
      <div>
        <label style={{ ...labelSm, fontSize: "11px" }}>Internal Note (optional)</label>
        <textarea
          placeholder="e.g. Quote for Vertex Financial — Enhanced + Standard DBS bundle"
          value={note}
          onChange={e => setNote(e.target.value)}
          rows={2}
          style={{
            ...inputBase,
            height: "auto",
            padding: "8px",
            resize: "vertical",
            lineHeight: "1.5",
          }}
        />
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button
          onClick={reset}
          className="flex items-center gap-1.5 flex-1 justify-center rounded-xl py-2 text-xs font-semibold transition-all duration-150"
          style={{
            background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)",
            border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)",
            color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)",
            cursor: "pointer",
          }}
        >
          <RotateCcw style={{ width: "12px", height: "12px" }} />
          Reset
        </button>
        <button
          onClick={copySummary}
          className="flex items-center gap-1.5 flex-1 justify-center rounded-xl py-2 text-xs font-semibold transition-all duration-150"
          style={{
            background: copied ? "rgba(16,185,129,0.18)" : `${accentColor}18`,
            border: `1px solid ${copied ? "#10b981" : accentColor}40`,
            color: copied ? "#10b981" : accentColor,
            cursor: "pointer",
          }}
        >
          {copied ? <Check style={{ width: "12px", height: "12px" }} /> : <Copy style={{ width: "12px", height: "12px" }} />}
          {copied ? "Copied!" : "Copy Breakdown"}
        </button>
      </div>
    </div>
  );
}