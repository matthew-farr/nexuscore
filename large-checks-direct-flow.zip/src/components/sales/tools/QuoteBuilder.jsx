import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";

export default function QuoteBuilder({ isDark, accentColor }) {
  const [client, setClient] = useState("");
  const [items, setItems] = useState([{ desc: "", qty: "1", price: "" }]);

  const addItem = () => setItems([...items, { desc: "", qty: "1", price: "" }]);
  const removeItem = i => setItems(items.filter((_, idx) => idx !== i));
  const updateItem = (i, field, val) => {
    const updated = [...items];
    updated[i] = { ...updated[i], [field]: val };
    setItems(updated);
  };

  const subtotal = items.reduce((sum, item) => sum + (parseFloat(item.price) || 0) * (parseInt(item.qty) || 0), 0);
  const vat = subtotal * 0.2;
  const total = subtotal + vat;

  const inputStyle = (flex) => ({
    height: "34px", borderRadius: "8px", padding: "0 10px", fontSize: "12px",
    background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)",
    border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)",
    color: isDark ? "rgba(255,255,255,0.85)" : "hsl(230 25% 15%)", outline: "none", flex,
  });

  return (
    <div className="space-y-3">
      <div>
        <label style={{ fontSize: "11px", fontWeight: 600, display: "block", marginBottom: "4px", color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
          Client Name
        </label>
        <input placeholder="e.g. Vertex Financial Ltd" value={client} onChange={e => setClient(e.target.value)} style={{ ...inputStyle("1"), width: "100%", height: "38px" }} />
      </div>

      <div className="space-y-1.5">
        <div className="grid gap-1.5" style={{ gridTemplateColumns: "1fr 48px 80px 28px" }}>
          {["Description", "Qty", "Price (£)", ""].map((h, i) => (
            <span key={i} style={{ fontSize: "10px", fontWeight: 600, color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)", paddingLeft: "4px" }}>{h}</span>
          ))}
        </div>
        {items.map((item, i) => (
          <div key={i} className="grid gap-1.5 items-center" style={{ gridTemplateColumns: "1fr 48px 80px 28px" }}>
            <input placeholder="Item description" value={item.desc} onChange={e => updateItem(i, "desc", e.target.value)} style={inputStyle("1")} />
            <input type="number" min="1" value={item.qty} onChange={e => updateItem(i, "qty", e.target.value)} style={inputStyle(null)} />
            <input type="number" placeholder="0.00" value={item.price} onChange={e => updateItem(i, "price", e.target.value)} style={inputStyle(null)} />
            <button onClick={() => removeItem(i)} style={{ width: "28px", height: "28px", borderRadius: "7px", background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.20)", color: "#ef4444", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Trash2 style={{ width: "11px", height: "11px" }} />
            </button>
          </div>
        ))}
        <button onClick={addItem} className="flex items-center gap-1.5 mt-1" style={{ fontSize: "11px", fontWeight: 600, color: accentColor, background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}>
          <Plus style={{ width: "12px", height: "12px" }} /> Add Line Item
        </button>
      </div>

      <div className="rounded-xl p-3 space-y-1.5" style={{ background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)", border: isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.06)" }}>
        {[["Subtotal", `£${subtotal.toFixed(2)}`], ["VAT (20%)", `£${vat.toFixed(2)}`]].map(([l, v]) => (
          <div key={l} className="flex justify-between" style={{ borderBottom: isDark ? "1px solid rgba(255,255,255,0.05)" : "1px solid rgba(0,0,0,0.05)", paddingBottom: "6px" }}>
            <span style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.50)" }}>{l}</span>
            <span style={{ fontSize: "12px", color: isDark ? "rgba(255,255,255,0.80)" : "hsl(230 25% 15%)" }}>{v}</span>
          </div>
        ))}
        <div className="flex justify-between pt-0.5">
          <span style={{ fontSize: "13px", fontWeight: 700, color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 12%)" }}>Total</span>
          <span style={{ fontSize: "16px", fontWeight: 800, color: accentColor }}>£{total.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}