import { useState } from "react";
import { motion } from "framer-motion";
import { Search, BookOpen, Star, Clock, Tag, ArrowRight, Pin } from "lucide-react";
import { useTheme } from "../../ThemeProvider";
import { useSalesHubBranding } from "../SalesHubBrandingContext";

const CATEGORIES = ["All", "Sales Process", "DBS Guidance", "Pricing", "Objection Handling", "Proposals", "Product Info"];

const GUIDES = [
  { title: "Sales Process — End to End",         category: "Sales Process",      meta: "12 min read",  pinned: true,  badge: "Essential" },
  { title: "DBS Check Types & Levels Guide",      category: "DBS Guidance",       meta: "8 min read",   pinned: true,  badge: "Essential" },
  { title: "Objection Handling Playbook",         category: "Objection Handling", meta: "10 min read",  pinned: false, badge: "Popular" },
  { title: "Enterprise Pricing Structure 2026",   category: "Pricing",            meta: "5 min read",   pinned: true,  badge: "Updated" },
  { title: "Proposal Best Practice Guide",        category: "Proposals",          meta: "7 min read",   pinned: false },
  { title: "Basic DBS — Who Qualifies?",          category: "DBS Guidance",       meta: "4 min read",   pinned: false },
  { title: "Enhanced DBS Eligibility Criteria",   category: "DBS Guidance",       meta: "6 min read",   pinned: false, badge: "Updated" },
  { title: "Standard vs Enhanced — Comparison",  category: "DBS Guidance",       meta: "3 min read",   pinned: false },
  { title: "Pricing by Sector — 2026",           category: "Pricing",            meta: "6 min read",   pinned: false },
  { title: "Product Suite Overview",              category: "Product Info",       meta: "9 min read",   pinned: false },
  { title: "Writing a Winning Proposal",          category: "Proposals",          meta: "11 min read",  pinned: false, badge: "New" },
  { title: "Regulated Sector Selling Guide",      category: "Sales Process",      meta: "14 min read",  pinned: false },
];

const badgeColors = {
  Essential: "#ec4899",
  Popular: "#8b5cf6",
  Updated: "#06b6d4",
  New: "#10b981",
};

export default function SalesGuidesTab() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const branding = useSalesHubBranding();
  const ACCENT = branding.accent_colour || "#06b6d4";
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = GUIDES.filter(g => {
    const matchCat = activeCategory === "All" || g.category === activeCategory;
    const matchSearch = !search || g.title.toLowerCase().includes(search.toLowerCase()) || g.category.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const pinned = filtered.filter(g => g.pinned);
  const rest = filtered.filter(g => !g.pinned);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* Header + Search */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="flex-1">
          <h2 className="text-base font-semibold" style={{ color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 15%)" }}>
            Sales Guides
          </h2>
          <p className="text-xs mt-0.5" style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}>
            Operational knowledge — stay in context, find answers fast.
          </p>
        </div>
        {/* Search */}
        <div
          className="relative flex items-center gap-2 px-3 rounded-xl"
          style={{
            height: "38px",
            width: "220px",
            background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)",
            border: isDark ? "1px solid rgba(255,255,255,0.09)" : "1px solid rgba(0,0,0,0.08)",
          }}
        >
          <Search className="w-3.5 h-3.5 flex-shrink-0" style={{ color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)" }} />
          <input
            type="text"
            placeholder="Search guides…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="flex-1 bg-transparent focus:outline-none text-xs"
            style={{ color: isDark ? "rgba(255,255,255,0.80)" : "hsl(230 25% 15%)" }}
          />
        </div>
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap gap-2 mb-5 overflow-x-auto pb-1">
        {CATEGORIES.map(cat => {
          const isActive = activeCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
              style={{
                background: isActive
                  ? `${ACCENT}20`
                  : (isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)"),
                border: isActive
                  ? `1px solid ${ACCENT}40`
                  : (isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.07)"),
                color: isActive
                  ? ACCENT
                  : (isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)"),
                cursor: "pointer",
              }}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Pinned */}
      {pinned.length > 0 && (
        <div className="mb-5">
          <div className="flex items-center gap-1.5 mb-2">
            <Pin className="w-3 h-3" style={{ color: isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.30)" }} />
            <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.30)" }}>
              Pinned
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {pinned.map((g, i) => <GuideCard key={i} guide={g} isDark={isDark} accent={ACCENT} />)}
          </div>
        </div>
      )}

      {/* All */}
      {rest.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2">
            <BookOpen className="w-3 h-3" style={{ color: isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.30)" }} />
            <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: isDark ? "rgba(255,255,255,0.30)" : "rgba(0,0,0,0.30)" }}>
              All Guides
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {rest.map((g, i) => <GuideCard key={i} guide={g} isDark={isDark} accent={ACCENT} />)}
          </div>
        </div>
      )}

      {filtered.length === 0 && (
        <div className="py-16 text-center">
          <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-20" style={{ color: ACCENT }} />
          <p className="text-sm" style={{ color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)" }}>
            No guides match your search
          </p>
        </div>
      )}
    </motion.div>
  );
}

function GuideCard({ guide, isDark, accent }) {
  const ACCENT = accent || "#06b6d4";
  return (
    <div
      className="group relative rounded-xl p-4 flex flex-col gap-2 cursor-pointer transition-all duration-150"
      style={{
        background: isDark
          ? "linear-gradient(145deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)"
          : "linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(248,246,255,0.85) 100%)",
        border: isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.07)",
        backdropFilter: "blur(20px)",
      }}
      onMouseEnter={e => {
        e.currentTarget.style.borderColor = `${ACCENT}35`;
        e.currentTarget.style.transform = "translateY(-1px)";
        e.currentTarget.style.boxShadow = `0 6px 20px ${ACCENT}15`;
      }}
      onMouseLeave={e => {
        e.currentTarget.style.borderColor = isDark ? "rgba(255,255,255,0.07)" : "rgba(0,0,0,0.07)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-semibold leading-snug flex-1" style={{ color: isDark ? "rgba(255,255,255,0.85)" : "hsl(230 25% 15%)" }}>
          {guide.title}
        </p>
        {guide.badge && (
          <span
            className="text-[9px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0"
            style={{
              background: `${badgeColors[guide.badge]}18`,
              color: badgeColors[guide.badge],
              border: `1px solid ${badgeColors[guide.badge]}30`,
            }}
          >
            {guide.badge}
          </span>
        )}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className="text-[10px] px-2 py-0.5 rounded-md"
            style={{
              background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)",
            }}
          >
            {guide.category}
          </span>
          <span className="text-[10px]" style={{ color: isDark ? "rgba(255,255,255,0.28)" : "rgba(0,0,0,0.32)" }}>
            {guide.meta}
          </span>
        </div>
        <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-50 transition-opacity" style={{ color: ACCENT }} />
      </div>
    </div>
  );
}