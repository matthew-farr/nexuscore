import { motion } from "framer-motion";
import { Sparkles, Zap, MessageSquare, FileText, TrendingUp } from "lucide-react";
import { useTheme } from "../../ThemeProvider";
import { useSalesHubBranding } from "../SalesHubBrandingContext";

const PLANNED = [
  { icon: MessageSquare, label: "Conversational deal support" },
  { icon: FileText,      label: "Proposal drafting assistant" },
  { icon: TrendingUp,    label: "Intelligent pipeline recommendations" },
  { icon: Zap,           label: "Live DBS & pricing guidance" },
];

export default function SalesAITab() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const branding = useSalesHubBranding();
  const ACCENT = branding.accent_colour || "#06b6d4";
  const ACCENT2 = "#8b5cf6";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="flex items-center justify-center min-h-[500px]"
    >
      <div className="text-center max-w-md">
        {/* Icon */}
        <div className="flex items-center justify-center mb-6">
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center relative"
            style={{
              background: `linear-gradient(135deg, ${ACCENT}20, ${ACCENT2}15)`,
              border: `1px solid ${ACCENT}30`,
              boxShadow: `0 0 40px ${ACCENT}25, 0 0 80px ${ACCENT2}10`,
            }}
          >
            <Sparkles className="w-9 h-9" style={{ color: ACCENT }} />
            <div
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center"
              style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})`, boxShadow: `0 2px 8px ${ACCENT}50` }}
            >
              <Zap className="w-2.5 h-2.5 text-white" />
            </div>
          </div>
        </div>

        {/* Heading */}
        <h2
          className="text-xl font-bold mb-2"
          style={{ color: isDark ? "rgba(255,255,255,0.92)" : "hsl(230 25% 12%)" }}
        >
          AI Sales Assistant
        </h2>
        <p
          className="text-sm mb-1 font-semibold"
          style={{
            background: `linear-gradient(90deg, ${ACCENT}, ${ACCENT2})`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Coming Soon
        </p>
        <p
          className="text-xs leading-relaxed mb-8"
          style={{ color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)" }}
        >
          Operational sales guidance, proposal support, and intelligent recommendations will live here — built directly into your Sales Hub workspace.
        </p>

        {/* Planned features */}
        <div className="space-y-2 text-left">
          {PLANNED.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.35, delay: 0.1 + i * 0.06 }}
                className="flex items-center gap-3 px-4 py-2.5 rounded-xl"
                style={{
                  background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)",
                  border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
                }}
              >
                <Icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: ACCENT }} />
                <span className="text-xs" style={{ color: isDark ? "rgba(255,255,255,0.65)" : "rgba(0,0,0,0.60)" }}>
                  {item.label}
                </span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}