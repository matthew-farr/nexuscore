/**
 * SalesCustomTab — renders any admin-created custom tab using the Widget Framework V1.
 * Loads HubContentItem widget records and renders them via WidgetLayoutGrid.
 */
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useSalesHubBranding } from "../SalesHubBrandingContext";
import WidgetLayoutGrid from "../../widgets/WidgetLayoutGrid";

export default function SalesCustomTab({ tabKey, tabLabel }) {
  const branding = useSalesHubBranding();
  const ACCENT = branding.accent_colour || "#ec2ca3";

  const [widgets, setWidgets] = useState([]);
  const [layout, setLayout] = useState("single");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tabKey) return;
    loadWidgets();
  }, [tabKey]);

  const loadWidgets = async () => {
    setLoading(true);
    try {
      const items = await base44.entities.HubContentItem.filter(
        { hub_key: "sales", category: tabKey, is_active: true },
        "sort_order",
        100
      );
      setWidgets(items || []);
      // Extract layout from first item's config_json if set
      if (items && items.length > 0 && items[0].config_json?.tab_layout) {
        setLayout(items[0].config_json.tab_layout);
      }
    } catch (err) {
      console.error("Failed to load tab widgets:", err);
      setWidgets([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", padding: "48px 0" }}>
        <div style={{ width: "22px", height: "22px", borderRadius: "50%", border: `2px solid ${ACCENT}30`, borderTopColor: ACCENT, animation: "spin 0.8s linear infinite" }} />
      </div>
    );
  }

  return (
    <WidgetLayoutGrid
      widgets={widgets}
      layout={layout}
      tabLabel={tabLabel}
      accentColour={ACCENT}
    />
  );
}