import { useSalesHubBranding } from "../SalesHubBrandingContext";
import SalesActionLauncher from "../SalesActionLauncher";
import SalesToolsHero from "../SalesToolsHero";
import SalesPowerBI from "../SalesPowerBI";
import SalesEnablementGrid from "../SalesEnablementGrid";
import SalesSidebar from "../SalesSidebar";
import HubActivityFeed from "../../hub/HubActivityFeed";
import HubAnnouncementCard from "../../hub/HubAnnouncementCard";
import { DollarSign, Phone, Activity, PlusCircle } from "lucide-react";

const ACTIVITY = [
  { icon: DollarSign, title: "Deal closed: Vertex Financial — £48,000",    meta: "1 hour ago" },
  { icon: Phone,      title: "Call logged with Meridian Corp by James T.",  meta: "3 hours ago" },
  { icon: Activity,   title: "Proposal sent to Orbis Group",                meta: "Yesterday" },
  { icon: PlusCircle, title: "New lead added: Sterling Advisors",           meta: "2 days ago" },
];

const ANNOUNCEMENTS = [
  { title: "June pipeline meeting — Monday 2 June, 09:30", date: "Upcoming" },
  { title: "New pricing approved for enterprise tier",      date: "Today" },
  { title: "Q1 commission statements now available",        date: "3 days ago" },
];

export default function SalesOverviewTab() {
  const branding = useSalesHubBranding();
  const ACCENT = branding.accent_colour || "#06b6d4";

  return (
    <div>
      {/* Sales Tools Hero */}
      <SalesToolsHero />

      {/* Full-width Quick Launch */}
      <SalesActionLauncher />

      {/* Main two-column layout */}
      <div className="flex flex-col xl:flex-row gap-4 mt-4">
        <div className="flex-1 min-w-0 space-y-4">
          <SalesPowerBI />
          <SalesEnablementGrid />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <HubActivityFeed items={ACTIVITY} accentColor={ACCENT} delay={0.30} />
            <HubAnnouncementCard announcements={ANNOUNCEMENTS} accentColor={ACCENT} delay={0.32} />
          </div>
        </div>
        <SalesSidebar />
      </div>
    </div>
  );
}