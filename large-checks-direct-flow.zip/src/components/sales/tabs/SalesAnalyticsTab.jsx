import { motion } from "framer-motion";
import { ExternalLink, BarChart2, RefreshCw } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../ThemeProvider";
import { useSalesHubBranding } from "../SalesHubBrandingContext";
// Replace this URL to update the embedded report
const POWER_BI_EMBED_URL = "https://app.powerbi.com/reportEmbed?reportId=8866abf5-7dda-4ebf-985d-4f2c1af26639&autoAuth=true&ctid=56d16e33-21b0-4f89-b37a-296d05ee8535";
const POWER_BI_FULL_URL = "https://app.powerbi.com/reportEmbed?reportId=8866abf5-7dda-4ebf-985d-4f2c1af26639&autoAuth=true&ctid=56d16e33-21b0-4f89-b37a-296d05ee8535";

export default function SalesAnalyticsTab() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const branding = useSalesHubBranding();
  const ACCENT = branding.accent_colour || "#06b6d4";
  const [loading, setLoading] = useState(true);
  const [key, setKey] = useState(0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      <div
        className="relative rounded-2xl overflow-hidden"
        style={{
          background: isDark
            ? "linear-gradient(145deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)"
            : "linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(248,246,255,0.85) 100%)",
          border: isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.07)",
          backdropFilter: "blur(20px)",
          boxShadow: isDark
            ? "0 4px 24px rgba(0,0,0,0.30), inset 0 1px 0 rgba(255,255,255,0.06)"
            : "0 2px 12px rgba(0,0,0,0.05), inset 0 1px 0 rgba(255,255,255,0.90)",
        }}
      >
        {/* Shimmer */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-px"
          style={{
            background: isDark
              ? "linear-gradient(to right, transparent, rgba(255,255,255,0.14), transparent)"
              : "linear-gradient(to right, transparent, rgba(255,255,255,0.90), transparent)",
          }}
        />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <BarChart2 className="w-4 h-4" style={{ color: ACCENT }} />
            <h2 className="text-sm font-semibold" style={{ color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 15%)" }}>
              Sales Analytics
            </h2>
            <span
              className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ background: `${ACCENT}18`, color: ACCENT, border: `1px solid ${ACCENT}30` }}
            >
              LIVE
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => { setLoading(true); setKey(k => k + 1); }}
              className="inline-flex items-center gap-1.5 text-xs font-medium px-3 transition-all duration-200"
              style={{
                height: "32px",
                borderRadius: "10px",
                background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)",
                border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.08)",
                color: isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)",
                cursor: "pointer",
              }}
            >
              <RefreshCw className="w-3 h-3" />
              Refresh
            </button>
            <button
              onClick={() => window.open(POWER_BI_FULL_URL, "_blank")}
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 transition-all duration-200"
              style={{
                height: "32px",
                borderRadius: "10px",
                background: isDark
                  ? "linear-gradient(135deg, rgba(6,182,212,0.18), rgba(14,165,233,0.12))"
                  : "linear-gradient(135deg, rgba(6,182,212,0.12), rgba(14,165,233,0.08))",
                border: `1px solid ${ACCENT}35`,
                color: ACCENT,
                cursor: "pointer",
              }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = `0 4px 16px ${ACCENT}30`; }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = "none"; }}
            >
              <ExternalLink className="w-3 h-3" />
              Open Full Report
            </button>
          </div>
        </div>

        {/* iFrame area */}
        <div style={{ height: "calc(100vh - 280px)", minHeight: 500, position: "relative" }}>
          {loading && (
            <div
              className="absolute inset-0 flex flex-col items-center justify-center z-10"
              style={{ background: isDark ? "rgba(6,10,24,0.7)" : "rgba(255,255,255,0.7)" }}
            >
              <div className="w-8 h-8 border-2 border-primary/20 border-t-primary rounded-full animate-spin mb-3" style={{ borderTopColor: ACCENT }} />
              <p className="text-xs" style={{ color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)" }}>
                Loading analytics…
              </p>
            </div>
          )}
          <iframe
            key={key}
            src={POWER_BI_EMBED_URL}
            frameBorder="0"
            allowFullScreen
            onLoad={() => setLoading(false)}
            title="Sales Analytics"
            style={{
              display: "block",
              width: "100%",
              height: "100%",
              border: "none",
            }}
          />
        </div>
      </div>
    </motion.div>
  );
}