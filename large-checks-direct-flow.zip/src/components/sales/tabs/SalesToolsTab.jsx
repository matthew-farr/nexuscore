import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, X, ChevronRight } from "lucide-react";
import { useTheme } from "../../ThemeProvider";
import { base44 } from "@/api/base44Client";
import { TOOL_REGISTRY, COLOUR_MAP } from "../salesToolsConfig";

const ACCENT = "#06b6d4";

export default function SalesToolsTab() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [activeTool, setActiveTool] = useState(null);
  const [tools, setTools] = useState([]);

  useEffect(() => {
    base44.entities.SalesHubTool.filter({ is_active: true }, "sort_order", 100)
      .then(data => setTools(data || []))
      .catch(() => setTools([]));
  }, []);

  const activeToolDef = activeTool ? TOOL_REGISTRY[activeTool] : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* Header */}
      <div className="mb-4">
        <h2 className="text-base font-semibold" style={{ color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 15%)" }}>
          Sales Tools
        </h2>
        <p className="text-xs mt-0.5" style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}>
          Internal utility suite — calculators and builders for the sales team.
        </p>
      </div>

      {/* Tool Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {tools.map((t, i) => {
          const reg = TOOL_REGISTRY[t.title];
          const color = reg?.color || COLOUR_MAP[t.colour_theme] || "#06b6d4";
          const Icon = reg?.icon || FileText;
          return (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: i * 0.05 }}
              className="relative rounded-2xl p-5 flex flex-col gap-3 cursor-pointer group overflow-hidden"
              style={{
                background: isDark
                  ? `linear-gradient(145deg, rgba(15, 23, 42, 0.72) 0%, rgba(15, 23, 42, 0.55) 100%)`
                  : "linear-gradient(145deg, rgba(255,255,255,0.98) 0%, rgba(250,248,255,0.92) 100%)",
                border: isDark ? "1px solid rgba(255,255,255,0.12)" : `1px solid rgba(199,210,254,0.40)`,
                boxShadow: isDark
                  ? "0 20px 50px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.08) inset"
                  : "0 12px 32px rgba(99,102,241,0.12), 0 4px 12px rgba(0,0,0,0.08), 0 0 0 1px rgba(255,255,255,0.80) inset",
                transition: "all 0.3s ease",
              }}
              onClick={() => reg && setActiveTool(t.title)}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = isDark ? "rgba(236,44,163,0.45)" : "rgba(236,44,163,0.50)";
                e.currentTarget.style.transform = "translateY(-4px)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = isDark ? "rgba(255,255,255,0.12)" : "rgba(199,210,254,0.40)";
                e.currentTarget.style.transform = "translateY(0)";
              }}
            >
              <div className="relative z-10">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${color}25, ${color}12)`,
                    border: `1.5px solid ${color}40`,
                    boxShadow: `0 0 20px ${color}25`,
                  }}
                >
                  <Icon className="w-5 h-5" style={{ color }} />
                </div>
              </div>
              <div className="flex-1 relative z-10">
                <h3 className="text-sm font-bold mb-1" style={{ color: isDark ? "#ffffff" : "hsl(230 25% 10%)" }}>
                  {t.title}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: isDark ? "rgba(255,255,255,0.48)" : "rgba(0,0,0,0.50)" }}>
                  {t.description}
                </p>
              </div>
              {reg && (
                <button
                  type="button"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold px-4 self-start relative z-10 shadow-md transition-all duration-200"
                  style={{
                    height: "32px",
                    borderRadius: "9px",
                    background: `linear-gradient(135deg, ${color}30, ${color}18)`,
                    border: `1px solid ${color}45`,
                    color,
                    cursor: "pointer",
                  }}
                >
                  Launch
                  <ChevronRight className="w-3 h-3" />
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Tool Modal */}
      <AnimatePresence>
        {activeTool && activeToolDef && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(0,0,0,0.65)", backdropFilter: "blur(6px)" }}
            onClick={() => setActiveTool(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 8 }}
              transition={{ duration: 0.25 }}
              className="relative w-full rounded-2xl overflow-hidden"
              style={{
                maxWidth: activeToolDef.key === "pricing" ? "860px" : activeToolDef.key === "datebetween" ? "520px" : "560px",
                background: isDark ? "#080e20" : "#ffffff",
                border: isDark ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.10)",
                boxShadow: "0 24px 64px rgba(0,0,0,0.40)",
                maxHeight: "90vh",
                overflowY: "auto",
              }}
              onClick={e => e.stopPropagation()}
            >
              <div
                className="flex items-center justify-between px-5 py-4"
                style={{ borderBottom: isDark ? "1px solid rgba(255,255,255,0.07)" : "1px solid rgba(0,0,0,0.07)" }}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center"
                    style={{ background: `${activeToolDef.color}20`, border: `1px solid ${activeToolDef.color}30` }}
                  >
                    <activeToolDef.icon className="w-3.5 h-3.5" style={{ color: activeToolDef.color }} />
                  </div>
                  <span className="text-sm font-semibold" style={{ color: isDark ? "rgba(255,255,255,0.88)" : "hsl(230 25% 15%)" }}>
                    {activeTool}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTool(null)}
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)", border: "none", cursor: "pointer" }}
                >
                  <X className="w-3.5 h-3.5" style={{ color: isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.45)" }} />
                </button>
              </div>
              <div className="p-5">
                <activeToolDef.component isDark={isDark} accentColor={activeToolDef.color} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}