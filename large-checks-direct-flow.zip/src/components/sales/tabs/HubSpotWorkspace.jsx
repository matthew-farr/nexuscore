import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useTheme } from "../../ThemeProvider";
import CRMKPICards from "../crm/CRMKPICards";
import TodaysWorkPanel from "../crm/TodaysWorkPanel";
import PipelineSnapshot from "../crm/PipelineSnapshot";
import MyAccountsPanel from "../crm/MyAccountsPanel";
import CRMQuickActions from "../crm/CRMQuickActions";
import CompanyDetailDrawer from "../../hubspot/CompanyDetailDrawer";
import { Search, X, Building2, Users, Briefcase, Loader2, ExternalLink } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useHubSpotOwners, resolveOwner } from "@/lib/hubspotUtils";

// ── Search result cards ───────────────────────────────────────────────────────

function CompanyCard({ company, onSelect, isDark, ownerMap }) {
  const p = company.properties || {};
  const ownerName = p.hubspot_owner_id ? resolveOwner(p.hubspot_owner_id, ownerMap) : null;
  const cdPortalUrl = p.cd_portal_id
    ? `https://portal.checksdirect.co.uk/admin/view-company.php?id=${p.cd_portal_id}`
    : null;

  return (
    <div className="rounded-xl border flex flex-col overflow-hidden hover:scale-[1.005] transition-all"
      style={{
        background: isDark ? "rgba(6,182,212,0.06)" : "rgba(6,182,212,0.04)",
        border: isDark ? "1px solid rgba(6,182,212,0.20)" : "1px solid rgba(6,182,212,0.18)",
      }}>
      {/* Clickable main area */}
      <button onClick={() => onSelect(company)} className="w-full text-left p-4 flex flex-col gap-2.5">
        {/* Header */}
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
            style={{ background: "rgba(6,182,212,0.18)" }}>
            <Building2 className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold leading-snug" style={{ color: isDark ? "#ffffff" : "#000000" }}>
              {p.name || "—"}
            </p>
            {ownerName && (
              <p className="text-[11px] font-medium mt-0.5" style={{ color: isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)" }}>
                👤 {ownerName}
              </p>
            )}
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5">
          {p.lifecyclestage && (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize"
              style={{ background: "rgba(139,92,246,0.15)", color: "#8b5cf6" }}>
              {p.lifecyclestage}
            </span>
          )}
          {p.hs_lead_status && (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ background: "rgba(16,185,129,0.12)", color: "#10b981" }}>
              {p.hs_lead_status}
            </span>
          )}
          {(p.cd_industry || p.industry) && (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ background: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)",
                color: isDark ? "rgba(255,255,255,0.70)" : "rgba(0,0,0,0.55)" }}>
              {p.cd_industry || p.industry}
            </span>
          )}
          {p.city && (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ background: "rgba(6,182,212,0.12)", color: "#06b6d4" }}>
              📍 {p.city}
            </span>
          )}
        </div>

        <p className="text-[11px] font-semibold" style={{ color: "#06b6d4" }}>
          Open Account 360 →
        </p>
      </button>

      {/* CD Portal ID — separate row, not inside the button */}
      {p.cd_portal_id && (
        <div className="px-4 pb-3 flex items-center gap-2 border-t"
          style={{ borderColor: isDark ? "rgba(6,182,212,0.12)" : "rgba(6,182,212,0.10)" }}>
          <span className="text-[10px] font-semibold uppercase tracking-wide pt-2"
            style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}>
            CD Portal:
          </span>
          <a href={cdPortalUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
            className="flex items-center gap-1 text-[11px] font-bold pt-2 hover:underline"
            style={{ color: "#06b6d4" }}>
            {p.cd_portal_id}
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}
    </div>
  );
}

function ContactCard({ contact, isDark }) {
  const p = contact.properties || {};
  const name = [p.firstname, p.lastname].filter(Boolean).join(" ") || "—";
  return (
    <div className="rounded-xl border p-4 flex flex-col gap-2"
      style={{
        background: isDark ? "rgba(16,185,129,0.06)" : "rgba(16,185,129,0.04)",
        border: isDark ? "1px solid rgba(16,185,129,0.20)" : "1px solid rgba(16,185,129,0.18)",
      }}>
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: "rgba(16,185,129,0.18)" }}>
          <Users className="w-4 h-4 text-emerald-500" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold truncate" style={{ color: isDark ? "#ffffff" : "#000000" }}>{name}</p>
          {p.jobtitle && <p className="text-[11px] truncate" style={{ color: isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.50)" }}>{p.jobtitle}</p>}
        </div>
      </div>
      {p.email && (
        <p className="text-[11px] truncate" style={{ color: isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.55)" }}>{p.email}</p>
      )}
      {contact.url && (
        <a href={contact.url} target="_blank" rel="noreferrer"
          className="text-[10px] font-semibold px-2.5 py-1 rounded-lg self-start"
          style={{ background: "rgba(16,185,129,0.15)", color: "#10b981", border: "1px solid rgba(16,185,129,0.25)" }}>
          Open in HubSpot →
        </a>
      )}
    </div>
  );
}

function DealCard({ deal, isDark }) {
  const p = deal.properties || {};
  return (
    <div className="rounded-xl border p-4 flex flex-col gap-2"
      style={{
        background: isDark ? "rgba(139,92,246,0.06)" : "rgba(139,92,246,0.04)",
        border: isDark ? "1px solid rgba(139,92,246,0.20)" : "1px solid rgba(139,92,246,0.18)",
      }}>
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: "rgba(139,92,246,0.18)" }}>
          <Briefcase className="w-4 h-4 text-violet-500" />
        </div>
        <p className="text-sm font-bold truncate" style={{ color: isDark ? "#ffffff" : "#000000" }}>
          {p.dealname || "—"}
        </p>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {p.dealstage && (
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
            style={{ background: "rgba(139,92,246,0.12)", color: "#8b5cf6" }}>
            {p.dealstage}
          </span>
        )}
        {p.amount && (
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
            style={{ background: "rgba(6,182,212,0.12)", color: "#06b6d4" }}>
            £{Number(p.amount).toLocaleString()}
          </span>
        )}
      </div>
      {deal.url && (
        <a href={deal.url} target="_blank" rel="noreferrer"
          className="text-[10px] font-semibold px-2.5 py-1 rounded-lg self-start"
          style={{ background: "rgba(139,92,246,0.15)", color: "#8b5cf6", border: "1px solid rgba(139,92,246,0.25)" }}>
          Open in HubSpot →
        </a>
      )}
    </div>
  );
}

// ── Main workspace ────────────────────────────────────────────────────────────

export default function HubSpotWorkspace() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const ownerMap = useHubSpotOwners();

  // Dashboard data
  const [dashboard, setDashboard]         = useState(null);
  const [dashLoading, setDashLoading]     = useState(true);
  const [dashError, setDashError]         = useState(null);

  // Search
  const [query, setQuery]                 = useState("");
  const [searching, setSearching]         = useState(false);
  const [searchResults, setSearchResults] = useState(null);
  const [portalId, setPortalId]           = useState(null);

  // Filters
  const [filters, setFilters] = useState({
    companies: true, contacts: true, deals: true
  });

  // Drawer
  const [drawerCompany, setDrawerCompany] = useState(null);

  // Quick actions
  const [selectedCompany, setSelectedCompany] = useState(null);

  // Load dashboard once
  useEffect(() => {
    (async () => {
      setDashLoading(true);
      setDashError(null);
      try {
        const res = await base44.functions.invoke("getHubSpotDashboard", {});
        setDashboard(res.data);
        if (res.data?.portal_id) setPortalId(res.data.portal_id);
      } catch (e) {
        setDashError(e.message);
      } finally {
        setDashLoading(false);
      }
    })();
  }, []);

  // Debounced search
  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setSearchResults(null);
      return;
    }
    const timer = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await base44.functions.invoke("searchHubSpotCompanies", {
          query: query.trim(),
          includeContacts: filters.contacts,
          includeDeals: filters.deals,
        });
        setSearchResults(res.data);
        if (res.data?.portalId) setPortalId(res.data.portalId);
      } catch (e) {
        setSearchResults({ companies: [], contacts: [], deals: [], error: e.message });
      } finally {
        setSearching(false);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [query, filters]);

  const handleAction = useCallback((key) => {
    if (!selectedCompany && (key === "call" || key === "note" || key === "task")) {
      alert("Please select a company first by clicking 'Details' on an account.");
      return;
    }
    if (selectedCompany) {
      setDrawerCompany(selectedCompany);
    }
  }, [selectedCompany]);

  const handleViewDetails = useCallback((company) => {
    setSelectedCompany(company);
    setDrawerCompany(company);
  }, []);

  const kpis = dashboard?.kpis || {};
  const tasksDueToday = dashboard?.tasks_due_today || [];
  const tasksOverdue  = dashboard?.tasks_overdue   || [];
  const pipelineStages = dashboard?.pipeline_stages || [];
  const recentCompanies = dashboard?.recent_companies || [];

  const showSearch = !!searchResults;

  const FILTER_PILLS = [
    { key: "companies", label: "Companies", colour: "#06b6d4" },
    { key: "contacts",  label: "Contacts",  colour: "#10b981" },
    { key: "deals",     label: "Deals",     colour: "#8b5cf6" },
  ];

  return (
    <div className="space-y-5 pb-8">
      {/* Search bar + filter pills */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.35)" }} />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search companies, contacts, deals…"
            className="w-full pl-10 pr-10 py-3 rounded-xl text-sm border outline-none transition-all"
            style={{
              background: isDark ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.85)",
              border: isDark ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.10)",
              color: isDark ? "#ffffff" : "#000000",
            }}
          />
          {searching && (
            <Loader2 className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-primary" />
          )}
          {!searching && query && (
            <button onClick={() => { setQuery(""); setSearchResults(null); }}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center rounded-full hover:opacity-70"
              style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.10)" }}>
              <X className="w-3 h-3" style={{ color: isDark ? "#ffffff" : "#000000" }} />
            </button>
          )}
        </div>

        {/* Filter pills */}
        <div className="flex gap-2">
          {FILTER_PILLS.map(pill => (
            <button key={pill.key}
              onClick={() => setFilters(f => ({ ...f, [pill.key]: !f[pill.key] }))}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-all"
              style={{
                background: filters[pill.key] ? `${pill.colour}18` : "transparent",
                border: filters[pill.key] ? `1px solid ${pill.colour}40` : `1px solid ${isDark ? "rgba(255,255,255,0.10)" : "rgba(0,0,0,0.10)"}`,
                color: filters[pill.key] ? pill.colour : (isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.45)"),
              }}>
              {pill.label}
            </button>
          ))}
        </div>
      </div>

      {/* Search results */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2 }}
            className="rounded-xl border overflow-hidden"
            style={{
              background: isDark ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.90)",
              border: isDark ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.08)",
            }}>
            {/* Quick Actions row when a company is selected */}
            {selectedCompany && (
              <div className="px-4 py-3 border-b"
                style={{ borderColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)" }}>
                <p className="text-[10px] font-semibold uppercase tracking-wide mb-2"
                  style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
                  Quick Actions — {selectedCompany.properties?.name}
                </p>
                <CRMQuickActions selectedCompany={selectedCompany} onAction={handleAction} isDark={isDark} />
              </div>
            )}

            {searchResults?.error && (
              <p className="px-4 py-3 text-sm text-destructive">{searchResults.error}</p>
            )}

            {/* Companies */}
            {filters.companies && searchResults?.companies?.length > 0 && (
              <div className="p-4 pb-2">
                <p className="text-[10px] font-bold uppercase tracking-wide mb-2"
                  style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
                  Companies ({searchResults.companies.length})
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {searchResults.companies.map(c => (
                    <CompanyCard key={c.id} company={c} onSelect={handleViewDetails} isDark={isDark} ownerMap={ownerMap} />
                  ))}
                </div>
              </div>
            )}

            {/* Contacts */}
            {filters.contacts && searchResults?.contacts?.length > 0 && (
              <div className="px-4 py-2">
                <p className="text-[10px] font-bold uppercase tracking-wide mb-2"
                  style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
                  Contacts ({searchResults.contacts.length})
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {searchResults.contacts.map(c => (
                    <ContactCard key={c.id} contact={c} isDark={isDark} />
                  ))}
                </div>
              </div>
            )}

            {/* Deals */}
            {filters.deals && searchResults?.deals?.length > 0 && (
              <div className="px-4 py-2 pb-4">
                <p className="text-[10px] font-bold uppercase tracking-wide mb-2"
                  style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
                  Deals ({searchResults.deals.length})
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {searchResults.deals.map(d => (
                    <DealCard key={d.id} deal={d} isDark={isDark} />
                  ))}
                </div>
              </div>
            )}

            {!searchResults?.error &&
              !searchResults?.companies?.length &&
              !searchResults?.contacts?.length &&
              !searchResults?.deals?.length && (
              <p className="px-4 py-5 text-sm text-center"
                style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.50)" }}>
                No results found for "{query}"
              </p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dashboard — always visible */}
      {/* KPI Cards */}
      <CRMKPICards kpis={kpis} loading={dashLoading} error={dashError} />

      {/* Quick Actions (dashboard state) */}
      <div className="rounded-xl border px-4 py-3"
        style={{
          background: isDark ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.80)",
          border: isDark ? "1px solid rgba(255,255,255,0.08)" : "1px solid rgba(0,0,0,0.07)",
        }}>
        <p className="text-[10px] font-semibold uppercase tracking-wide mb-2.5"
          style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.45)" }}>
          Quick Actions {selectedCompany ? `— ${selectedCompany.properties?.name}` : "— select a company first"}
        </p>
        <CRMQuickActions selectedCompany={selectedCompany} onAction={handleAction} isDark={isDark} />
      </div>

      {/* Today's Work + Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TodaysWorkPanel
          tasksDueToday={tasksDueToday}
          tasksOverdue={tasksOverdue}
          loading={dashLoading}
          error={dashError}
          isDark={isDark}
        />
        <PipelineSnapshot
          stages={pipelineStages}
          loading={dashLoading}
          error={dashError}
          isDark={isDark}
        />
      </div>

      {/* My Accounts */}
      <MyAccountsPanel
        companies={recentCompanies}
        loading={dashLoading}
        error={dashError}
        onViewDetails={handleViewDetails}
        isDark={isDark}
      />

      {/* Company Detail Drawer */}
      {drawerCompany && (
        <CompanyDetailDrawer
          company={drawerCompany}
          portalId={portalId}
          onClose={() => setDrawerCompany(null)}
        />
      )}
    </div>
  );
}