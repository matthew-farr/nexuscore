// Replaced by components/sales/crm/CRMQuickActions.jsx
// Kept as empty re-export to avoid any residual import errors
export default function HubSpotQuickActions() { return null; }