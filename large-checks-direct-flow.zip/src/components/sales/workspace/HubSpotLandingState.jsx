import { motion } from "framer-motion";
import { Building2, Users, Briefcase, Phone, FileText, CheckSquare, Mail } from "lucide-react";
import { useTheme } from "../../ThemeProvider";

const features = [
  { icon: Building2, label: "Companies" },
  { icon: Users, label: "Contacts" },
  { icon: Briefcase, label: "Deals" },
  { icon: Phone, label: "Calls" },
  { icon: FileText, label: "Notes" },
  { icon: CheckSquare, label: "Tasks" },
  { icon: Mail, label: "Emails" },
];

export default function HubSpotLandingState() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="flex flex-col items-center justify-center py-8 gap-6"
    >
      <div className="text-center space-y-2 max-w-lg">
        <h3 className="text-lg font-bold" style={{ color: isDark ? "#ffffff" : "#000000" }}>
          HubSpot CRM Command Centre
        </h3>
        <p style={{ color: isDark ? "#ffffff" : "#000000" }} className="text-xs opacity-75">
          Search across companies, contacts, deals and activity history without leaving Checks Direct OS.
        </p>
      </div>

      <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
        {features.map(({ icon: Icon, label }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.25, delay: i * 0.03 }}
            className="flex flex-col items-center gap-1.5"
          >
            <div
              className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{
                background: isDark ? "rgba(236,44,163,0.15)" : "rgba(236,44,163,0.08)",
                border: isDark ? "1px solid rgba(236,44,163,0.25)" : "1px solid rgba(236,44,163,0.20)",
              }}
            >
              <Icon className="w-4 h-4" style={{ color: "#ec2ca3" }} />
            </div>
            <p className="text-[10px] font-semibold text-center" style={{ color: isDark ? "#ffffff" : "#000000" }}>
              {label}
            </p>
          </motion.div>
        ))}
      </div>

      <p className="text-xs" style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}>
        Enter at least 2 characters to search
      </p>
    </motion.div>
  );
}