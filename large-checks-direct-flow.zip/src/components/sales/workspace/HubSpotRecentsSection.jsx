import { motion } from "framer-motion";
import { Clock, Building2, Users, Loader2 } from "lucide-react";
import { useTheme } from "../../ThemeProvider";

export default function HubSpotRecentsSection({ recentCompanies, recentContacts, loading }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const hasRecents = (recentCompanies?.length > 0) || (recentContacts?.length > 0);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-4 gap-3">
        <Loader2 className="w-4 h-4 animate-spin text-primary" />
        <p style={{ color: isDark ? "#ffffff" : "#000000" }} className="text-xs">
          Loading recent records…
        </p>
      </div>
    );
  }

  if (!hasRecents) {
    return (
      <div className="flex flex-col items-center justify-center py-4 gap-1.5">
        <p style={{ color: isDark ? "#ffffff" : "#000000" }} className="text-xs font-semibold">
          No recent records yet
        </p>
        <p
          className="text-[11px]"
          style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.50)" }}
        >
          Viewed and updated records will appear here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {recentCompanies && recentCompanies.length > 0 && (
        <div className="space-y-2">
          <p
            className="text-xs font-semibold uppercase tracking-wide"
            style={{ color: isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.60)" }}
          >
            Recent Companies
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {recentCompanies.slice(0, 4).map((company, i) => (
              <motion.div
                key={company.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, delay: i * 0.04 }}
                className="rounded-lg p-2.5 border flex items-center gap-2"
                style={{
                  background: isDark ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.60)",
                  border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
                }}
              >
                <div
                  className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0"
                  style={{ background: "rgba(6,182,212,0.15)" }}
                >
                  <Building2 className="w-3 h-3 text-cyan-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold truncate" style={{ color: isDark ? "#ffffff" : "#000000" }}>
                    {company.properties?.name || "—"}
                  </p>
                  <p
                    className="text-[10px] truncate"
                    style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}
                  >
                    {company.properties?.domain || company.properties?.city || "—"}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {recentContacts && recentContacts.length > 0 && (
        <div className="space-y-2">
          <p
            className="text-xs font-semibold uppercase tracking-wide"
            style={{ color: isDark ? "rgba(255,255,255,0.60)" : "rgba(0,0,0,0.60)" }}
          >
            Recent Contacts
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {recentContacts.slice(0, 4).map((contact, i) => (
              <motion.div
                key={contact.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, delay: i * 0.04 }}
                className="rounded-lg p-2.5 border flex items-center gap-2"
                style={{
                  background: isDark ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.60)",
                  border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
                }}
              >
                <div
                  className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0"
                  style={{ background: "rgba(16,185,129,0.15)" }}
                >
                  <Users className="w-3 h-3 text-green-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold truncate" style={{ color: isDark ? "#ffffff" : "#000000" }}>
                    {[contact.properties?.firstname, contact.properties?.lastname]
                      .filter(Boolean)
                      .join(" ") || "—"}
                  </p>
                  <p
                    className="text-[10px] truncate"
                    style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.40)" }}
                  >
                    {contact.properties?.email || contact.properties?.jobtitle || "—"}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}