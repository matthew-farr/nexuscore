import { motion } from "framer-motion";
import { Building2, Users, Briefcase, Zap } from "lucide-react";
import { useTheme } from "../../ThemeProvider";

const KPI_CONFIG = [
  { icon: Building2, label: "Companies", key: "companies_found", colour: "#06b6d4" },
  { icon: Users, label: "Contacts", key: "contacts_found", colour: "#10b981" },
  { icon: Briefcase, label: "Deals", key: "deals_found", colour: "#f59e0b" },
  { icon: Zap, label: "Activities", key: "activities_found", colour: "#8b5cf6" },
];

export default function HubSpotKPICards({ results }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {KPI_CONFIG.map(({ icon: Icon, label, key, colour }, i) => {
        const value = results?.[key] || 0;
        return (
          <motion.div
            key={key}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: i * 0.04 }}
            className="rounded-xl p-3 border"
            style={{
              background: isDark
                ? "linear-gradient(135deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)"
                : "linear-gradient(135deg, rgba(255,255,255,0.80) 0%, rgba(248,246,255,0.60) 100%)",
              border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
            }}
          >
            <div className="flex items-start justify-between">
              <div>
                <p
                  className="text-[10px] font-semibold uppercase tracking-wider"
                  style={{ color: isDark ? "rgba(255,255,255,0.50)" : "rgba(0,0,0,0.50)" }}
                >
                  {label}
                </p>
                <p className="text-2xl font-bold mt-1" style={{ color: isDark ? "#fff" : "#000" }}>
                  {value}
                </p>
              </div>
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: `${colour}22` }}
              >
                <Icon className="w-4 h-4" style={{ color: colour }} />
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}