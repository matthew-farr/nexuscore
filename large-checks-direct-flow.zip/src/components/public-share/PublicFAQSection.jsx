import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

function FAQItem({ item }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-slate-100 last:border-0">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-4 px-6 py-4 text-left hover:bg-slate-50/70 transition-colors"
      >
        <span className="text-sm font-semibold text-slate-800">{item.question}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 flex-shrink-0 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-6 pb-4">
          <p className="text-sm text-slate-500 leading-relaxed">{item.answer}</p>
        </div>
      )}
    </div>
  );
}

// On the public page, faqs are passed as a prop (fetched server-side via service role).
// In the admin preview (PublicFAQManager), faqs can be fetched client-side.
export default function PublicFAQSection({ doc, faqs = [] }) {
  const isApplicant = doc?.is_applicant_shareable;
  const isClient = doc?.is_client_shareable;

  const showTabs = isApplicant && isClient;
  const [activeTab, setActiveTab] = useState(isApplicant ? 'applicant' : 'client');

  if (!isApplicant && !isClient) return null;

  const filtered = faqs.filter(f => f.audience === activeTab && f.is_active !== false);

  return (
    <div className="h-full">
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden h-full">
        <div className="px-6 py-4 border-b border-slate-100">
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Frequently Asked Questions</h2>
        </div>

        {showTabs && (
          <div className="flex border-b border-slate-100">
            {[
              { key: 'applicant', label: '👤 Applicant FAQs' },
              { key: 'client',    label: '🏢 Client FAQs' },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 px-6 py-3.5 text-sm font-semibold transition-colors ${
                  activeTab === tab.key
                    ? 'text-purple-700 border-b-2 border-purple-600 bg-purple-50/40'
                    : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        )}

        {!showTabs && (
          <div className="px-6 py-3.5 border-b border-slate-100">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {isApplicant ? '👤 Applicant FAQs' : '🏢 Client FAQs'}
            </p>
          </div>
        )}

        <div>
          {filtered.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8 px-6">No FAQs available yet.</p>
          ) : (
            filtered.map((item, i) => <FAQItem key={item.id || i} item={item} />)
          )}
        </div>
      </div>
    </div>
  );
}