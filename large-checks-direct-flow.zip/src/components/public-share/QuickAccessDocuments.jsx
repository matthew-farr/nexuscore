import { FileText, ExternalLink } from 'lucide-react';

const QUICK_ACCESS_DOCS = [
  {
    id: 1,
    title: 'Accepted ID Documents',
    type: 'Identity Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/60f89389c_preview19.html',
  },
  {
    id: 2,
    title: 'Choose the Correct DBS Check',
    type: 'DBS Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/15eccc0b7_preview22.html',
  },
  {
    id: 3,
    title: 'Log in problems',
    type: 'Portal Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/5b6cf5f62_preview23.html',
  },
  {
    id: 4,
    title: 'DBS Application Journey',
    type: 'DBS Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/dc5d69693_preview24.html',
  },
  {
    id: 5,
    title: 'DBS ID Checking Guide',
    type: 'DBS Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/5dee31774_preview27.html',
  },
  {
    id: 6,
    title: 'Digital RTW Guidance',
    type: 'Client Guide',
    url: 'https://media.base44.com/files/public/6a16abdb83b84eec69c55112/31c62a2d6_preview28.html',
  },
];

export default function QuickAccessDocuments({ onOpenHtml }) {
  return (
    <section className="mb-10">
      <div className="mb-4 px-1">
        <h2 className="text-base font-bold text-slate-700">Quick Access Documents</h2>
        <p className="text-xs text-slate-400 mt-0.5">Commonly viewed guides and resources</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {QUICK_ACCESS_DOCS.map(doc => (
          <button
            key={doc.id}
            onClick={() => onOpenHtml(doc.url)}
            type="button"
            className="flex flex-col items-center justify-center gap-2 px-3 py-4 bg-white border border-slate-200 rounded-lg hover:border-purple-300 hover:shadow-sm transition-all group cursor-pointer h-28"
          >
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center flex-shrink-0 group-hover:bg-purple-100 transition-colors">
              <FileText className="w-4 h-4 text-purple-500" />
            </div>
            <div className="flex-1 min-w-0 text-center">
              <p className="text-[11px] font-semibold text-slate-700 line-clamp-2 leading-tight">{doc.title}</p>
              <p className="text-[9px] text-slate-400 mt-1">{doc.type}</p>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}