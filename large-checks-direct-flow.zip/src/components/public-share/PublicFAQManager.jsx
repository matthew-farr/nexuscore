import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, GripVertical, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const EMPTY_FORM = { question: '', answer: '', audience: 'applicant', sort_order: 0, is_active: true };

function FAQForm({ initial = EMPTY_FORM, onSave, onCancel }) {
  const [form, setForm] = useState(initial);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 [&_input]:text-slate-900 [&_textarea]:text-slate-900 [&_input]:bg-white [&_textarea]:bg-white">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500 mb-1 block">Question</label>
          <Input value={form.question} onChange={e => set('question', e.target.value)} placeholder="Enter question…" />
        </div>
        <div className="sm:col-span-2">
          <label className="text-xs font-semibold text-slate-500 mb-1 block">Answer</label>
          <Textarea value={form.answer} onChange={e => set('answer', e.target.value)} placeholder="Enter answer…" rows={3} />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 mb-1 block">Audience</label>
          <Select value={form.audience} onValueChange={v => set('audience', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="applicant">👤 Applicant</SelectItem>
              <SelectItem value="client">🏢 Client</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 mb-1 block">Sort Order</label>
          <Input type="number" value={form.sort_order} onChange={e => set('sort_order', parseInt(e.target.value) || 0)} />
        </div>
      </div>
      <div className="flex gap-2 justify-end">
        <Button variant="outline" size="sm" onClick={onCancel}><X className="w-3.5 h-3.5 mr-1" />Cancel</Button>
        <Button size="sm" onClick={() => onSave(form)} disabled={!form.question.trim() || !form.answer.trim()}>
          <Check className="w-3.5 h-3.5 mr-1" />Save
        </Button>
      </div>
    </div>
  );
}

function FAQRow({ faq, onEdit, onDelete }) {
  const audienceLabel = faq.audience === 'applicant' ? '👤 Applicant' : '🏢 Client';
  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border ${faq.is_active ? 'bg-white border-slate-200' : 'bg-slate-50 border-slate-100 opacity-60'}`}>
      <GripVertical className="w-4 h-4 text-slate-300 mt-0.5 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold text-slate-400">{audienceLabel}</span>
          {!faq.is_active && <span className="text-xs px-1.5 py-0.5 rounded bg-slate-200 text-slate-500">Hidden</span>}
        </div>
        <p className="text-sm font-semibold text-slate-800 mb-0.5">{faq.question}</p>
        <p className="text-xs text-slate-500 line-clamp-2">{faq.answer}</p>
      </div>
      <div className="flex gap-1 flex-shrink-0">
        <button onClick={() => onEdit(faq)} className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors">
          <Pencil className="w-3.5 h-3.5 text-slate-400" />
        </button>
        <button onClick={() => onDelete(faq.id)} className="p-1.5 rounded-lg hover:bg-red-50 transition-colors">
          <Trash2 className="w-3.5 h-3.5 text-red-400" />
        </button>
      </div>
    </div>
  );
}

export default function PublicFAQManager() {
  const qc = useQueryClient();
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState(null); // faq object

  const { data: faqs = [], isLoading } = useQuery({
    queryKey: ['public-faqs'],
    queryFn: () => base44.entities.PublicFAQ.list('sort_order', 200),
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ['public-faqs'] });

  const createMut = useMutation({
    mutationFn: data => base44.entities.PublicFAQ.create(data),
    onSuccess: () => { invalidate(); setAdding(false); },
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PublicFAQ.update(id, data),
    onSuccess: () => { invalidate(); setEditing(null); },
  });

  const deleteMut = useMutation({
    mutationFn: id => base44.entities.PublicFAQ.delete(id),
    onSuccess: invalidate,
  });

  const applicantFaqs = faqs.filter(f => f.audience === 'applicant');
  const clientFaqs = faqs.filter(f => f.audience === 'client');

  if (isLoading) return <div className="py-8 text-center text-sm text-slate-400">Loading FAQs…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-800">Public FAQs</h3>
          <p className="text-xs text-slate-400 mt-0.5">Manage FAQs shown on public document share pages</p>
        </div>
        {!adding && (
          <Button size="sm" onClick={() => setAdding(true)}>
            <Plus className="w-3.5 h-3.5 mr-1" /> Add FAQ
          </Button>
        )}
      </div>

      {adding && (
        <FAQForm onSave={d => createMut.mutate(d)} onCancel={() => setAdding(false)} />
      )}

      {/* Applicant */}
      <div>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">👤 Applicant FAQs ({applicantFaqs.length})</p>
        <div className="space-y-2">
          {applicantFaqs.length === 0 && <p className="text-xs text-slate-400 py-3 text-center border border-dashed border-slate-200 rounded-xl">No applicant FAQs yet</p>}
          {applicantFaqs.map(faq => editing?.id === faq.id ? (
            <FAQForm key={faq.id} initial={editing}
              onSave={d => updateMut.mutate({ id: faq.id, data: d })}
              onCancel={() => setEditing(null)} />
          ) : (
            <FAQRow key={faq.id} faq={faq} onEdit={setEditing} onDelete={id => deleteMut.mutate(id)} />
          ))}
        </div>
      </div>

      {/* Client */}
      <div>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">🏢 Client FAQs ({clientFaqs.length})</p>
        <div className="space-y-2">
          {clientFaqs.length === 0 && <p className="text-xs text-slate-400 py-3 text-center border border-dashed border-slate-200 rounded-xl">No client FAQs yet</p>}
          {clientFaqs.map(faq => editing?.id === faq.id ? (
            <FAQForm key={faq.id} initial={editing}
              onSave={d => updateMut.mutate({ id: faq.id, data: d })}
              onCancel={() => setEditing(null)} />
          ) : (
            <FAQRow key={faq.id} faq={faq} onEdit={setEditing} onDelete={id => deleteMut.mutate(id)} />
          ))}
        </div>
      </div>
    </div>
  );
}