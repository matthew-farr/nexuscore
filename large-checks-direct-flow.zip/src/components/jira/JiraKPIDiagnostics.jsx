import { useState } from 'react';
import { AlertCircle } from 'lucide-react';
import { useTheme } from '../ThemeProvider';

export default function JiraKPIDiagnostics({ issues = [], activeTab = 'open' }) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const [expanded, setExpanded] = useState(false);
  
  const currentDataset = activeTab === 'open' ? issues.filter(i => i.status_category !== 'Done') : issues.filter(i => i.status_category === 'Done');
  const withResolvedDate = currentDataset.filter(i => i.resolved_at).length;
  const withoutResolvedDate = currentDataset.length - withResolvedDate;
  
  // Debug the actual resolved dates
  const resolvedDates = currentDataset
    .filter(i => i.resolved_at)
    .map(i => ({
      key: i.issue_key,
      resolved_at: i.resolved_at,
      parsed: new Date(i.resolved_at).toLocaleString('en-GB')
    }))
    .sort((a, b) => new Date(b.resolved_at) - new Date(a.resolved_at))
    .slice(0, 5);

  if (!expanded) {
    return (
      <button
        onClick={() => setExpanded(true)}
        className={`text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${isDark ? 'text-white/40 hover:text-white/60 bg-white/5' : 'text-slate-500 hover:text-slate-700 bg-slate-100'}`}
      >
        <AlertCircle className="w-3.5 h-3.5" />
        KPI Debug
      </button>
    );
  }

  return (
    <div className={`p-4 rounded-xl border ${isDark ? 'bg-white/5 border-white/10' : 'bg-slate-50 border-slate-200'}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold uppercase">KPI Diagnostics</p>
        <button
          onClick={() => setExpanded(false)}
          className={`text-xs ${isDark ? 'text-white/40 hover:text-white/60' : 'text-slate-500 hover:text-slate-700'}`}
        >
          ✕
        </button>
      </div>
      
      <div className="space-y-2 text-xs">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className={`${isDark ? 'text-white/50' : 'text-slate-600'}`}>Total {activeTab === 'open' ? 'Open' : 'Completed'} Issues:</p>
            <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{currentDataset.length}</p>
          </div>
          <div>
            <p className={`${isDark ? 'text-white/50' : 'text-slate-600'}`}>With Resolved Date:</p>
            <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{withResolvedDate}</p>
          </div>
          <div>
            <p className={`${isDark ? 'text-white/50' : 'text-slate-600'}`}>Missing Resolved Date:</p>
            <p className={`font-bold text-red-500`}>{withoutResolvedDate}</p>
          </div>
          <div>
            <p className={`${isDark ? 'text-white/50' : 'text-slate-600'}`}>Timezone:</p>
            <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Europe/London</p>
          </div>
        </div>

        <div className={`mt-3 p-3 rounded border ${isDark ? 'bg-white/3 border-white/5' : 'bg-white border-slate-200'}`}>
          <p className={`text-xs font-semibold mb-2 ${isDark ? 'text-white/70' : 'text-slate-700'}`}>Sample Resolved Dates (Latest 5):</p>
          <div className="space-y-1 font-mono text-xs">
            {resolvedDates.length > 0 ? resolvedDates.map(d => (
              <div key={d.key} className={isDark ? 'text-white/40' : 'text-slate-600'}>
                {d.key}: {d.parsed}
              </div>
            )) : (
              <div className={isDark ? 'text-white/30' : 'text-slate-400'}>No resolved dates found</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}